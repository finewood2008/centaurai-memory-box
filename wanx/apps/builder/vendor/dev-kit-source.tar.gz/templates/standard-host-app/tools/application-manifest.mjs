import { createRequire } from "node:module";

const require = createRequire(import.meta.url);

const semver = /^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/u;
const stable = "(?:0|[1-9][0-9]*)\\.(?:0|[1-9][0-9]*)\\.(?:0|[1-9][0-9]*)";
const rangePattern = new RegExp(`^(?:>=|<=|>|<|=)?${stable}(?: (?:>=|<=|>|<|=)?${stable})*$`);
const identifier = /^[a-z][a-z0-9._-]{1,127}$/u;
const capabilities = new Set(["identity.read", "experts.read", "experts.select", "http.request", "chat.stream", "files.upload"]);
const manifestFields = new Set(["applicationId", "name", "version", "protocolVersion", "releaseAccess", "runtime",
  "launchMode", "platform", "arch", "entrypoint", "capabilities", "description", "compatibility", "critical"]);
export const packagePlatforms = Object.freeze({ darwin: "macos", win32: "windows" });

function exactFields(value, fields) {
  return value && typeof value === "object" && !Array.isArray(value) &&
    Object.keys(value).length === fields.length && fields.every(field => Object.hasOwn(value, field));
}

function validRange(value) {
  const semverLib = require("semver");
  return typeof value === "string" && value.length <= 256 && rangePattern.test(value) &&
    semverLib.validRange(value) !== null && semverLib.minVersion(value) !== null;
}

function unique(values) {
  return new Set(values).size === values.length;
}

function validBackendContract(contract) {
  return exactFields(contract, ["id", "range", "features"]) &&
    typeof contract.id === "string" && identifier.test(contract.id) && validRange(contract.range) &&
    Array.isArray(contract.features) && contract.features.length <= 32 && unique(contract.features) &&
    contract.features.every(feature => typeof feature === "string" && identifier.test(feature));
}

function validResourceDependency(resource) {
  return exactFields(resource, ["kind", "resourceId", "minVersion"]) &&
    ["expert", "skill-package"].includes(resource.kind) &&
    typeof resource.resourceId === "string" && /^[a-z0-9][a-z0-9._-]{0,63}$/u.test(resource.resourceId) &&
    validVersion(resource.minVersion) && new RegExp(`^${stable}$`).test(resource.minVersion) &&
    resource.minVersion.split(".").every(part => Number(part) <= 2147483647);
}

function validCompatibility(value) {
  if (!exactFields(value, ["backendProductId", "clientRange", "hostProtocolRange",
    "backendContracts", "resourceDependencies", "localDataSchema"])) return false;
  const { backendProductId, clientRange, hostProtocolRange, backendContracts, resourceDependencies, localDataSchema } = value;
  return typeof backendProductId === "string" && identifier.test(backendProductId) &&
    validRange(clientRange) && validRange(hostProtocolRange) &&
    Array.isArray(backendContracts) && backendContracts.length <= 32 && backendContracts.every(validBackendContract) &&
    unique(backendContracts.map(contract => contract.id)) &&
    Array.isArray(resourceDependencies) && resourceDependencies.length <= 64 && resourceDependencies.every(validResourceDependency) &&
    unique(resourceDependencies.map(resource => resource.kind + ":" + resource.resourceId)) &&
    exactFields(localDataSchema, ["readRange", "writeVersion"]) && validRange(localDataSchema.readRange) &&
    validRange(localDataSchema.writeVersion) && require("semver").satisfies(localDataSchema.writeVersion, localDataSchema.readRange);
}

function validVersion(value) {
  if (typeof value !== "string" || value.length > 64) return false;
  const match = semver.exec(value);
  return Boolean(match &&
    match.slice(1, 4).every((part) => Number.isSafeInteger(Number(part))) &&
    !match[4]?.split(".").some((part) => /^0[0-9]+$/u.test(part)));
}

export function applicationManifestError(manifest) {
  if (!manifest || typeof manifest !== "object" || Array.isArray(manifest)) {
    return "INVALID_APPLICATION_MANIFEST";
  }
  if (typeof manifest.applicationId !== "string" ||
      !/^[a-z][a-z0-9._-]{1,63}$/u.test(manifest.applicationId)) return "INVALID_APPLICATION_ID";
  if (typeof manifest.name !== "string" || !manifest.name.trim() ||
      manifest.name.length > 128) return "INVALID_APPLICATION_NAME";
  if (!validVersion(manifest.version)) return "INVALID_APPLICATION_VERSION";
  if (manifest.protocolVersion !== 3) return "APPLICATION_PROTOCOL_UNSUPPORTED";
  if (Object.hasOwn(manifest, "releaseAccess") || !validCompatibility(manifest.compatibility) ||
      Object.keys(manifest).some(field => !manifestFields.has(field)) ||
      (manifest.critical !== undefined &&
        (!Array.isArray(manifest.critical) || manifest.critical.length))) {
    return "APPLICATION_CONTRACT_UNSUPPORTED";
  }
  if (manifest.compatibility.resourceDependencies.length) return "LOCAL_RESOURCE_BINDING_UNSUPPORTED";
  if (manifest.capabilities !== undefined &&
      (!Array.isArray(manifest.capabilities) || manifest.capabilities.some(capability => !capabilities.has(capability)))) {
    return "INVALID_APPLICATION_CAPABILITIES";
  }
  if (manifest.runtime !== "electron" || (manifest.launchMode ?? "shared") !== "shared") {
    return "APPLICATION_RUNTIME_UNSUPPORTED";
  }
  if ((manifest.platform !== undefined || manifest.arch !== undefined) &&
      (typeof manifest.platform !== "string" || !Object.hasOwn(packagePlatforms, manifest.platform) ||
        !["x64", "arm64"].includes(manifest.arch))) {
    return "APPLICATION_PLATFORM_UNSUPPORTED";
  }
  if (manifest.entrypoint !== "shell/main.cjs") return "INVALID_APPLICATION_ENTRYPOINT";
}

export const applicationManifestMessages = {
  INVALID_APPLICATION_MANIFEST: "应用清单格式不正确",
  INVALID_APPLICATION_ID: "应用标识不符合万象本地安装格式",
  INVALID_APPLICATION_NAME: "应用名称不能为空或超过 128 字符",
  INVALID_APPLICATION_VERSION: "应用版本必须为不超过 64 字符的有效 SemVer",
  INVALID_APPLICATION_ENTRYPOINT: "应用入口必须为 shell/main.cjs",
  APPLICATION_PROTOCOL_UNSUPPORTED: "新应用必须使用应用协议 3",
  APPLICATION_CONTRACT_UNSUPPORTED: "本地应用必须包含协议 3 兼容性合同，且不设置 releaseAccess",
  LOCAL_RESOURCE_BINDING_UNSUPPORTED: "当前本地安装路径不支持自动准备专家或技能包资源；请记录受影响功能并等待平台提供本地资源绑定合同",
  INVALID_APPLICATION_CAPABILITIES: "应用清单包含不支持的 Host 能力",
  APPLICATION_RUNTIME_UNSUPPORTED: "本地工具仅支持共享 Electron 运行时",
  APPLICATION_PLATFORM_UNSUPPORTED: "应用的目标系统或架构无效",
};
