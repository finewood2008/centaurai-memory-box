import { createHash } from "node:crypto";
import { lstat, mkdir, open, readFile, unlink } from "node:fs/promises";
import path from "node:path";
import { isDeepStrictEqual, parseArgs } from "node:util";
import { crc32, deflateRawSync } from "node:zlib";
import { applicationManifestError, applicationManifestMessages } from "./application-manifest.mjs";
import { assertBuildInventory, readBuildFiles } from "./build-files.mjs";

async function readJson(file) {
  if (!(await lstat(file)).isFile()) throw new Error("PACKAGE_UNSAFE_ENTRY");
  return JSON.parse(await readFile(file, "utf8"));
}

// Standard ZIP (UTF-8, deflate, Unix modes). readBuildFiles limits this package
// to 10,000 entries / 128 MiB, below ZIP64 limits. No OS archiver is required.
function zip(entries) {
  const local = [], central = [];
  let offset = 0, centralSize = 0;
  for (const [name, contents, entry] of entries) {
    const directory = entry.kind === "directory";
    const filename = Buffer.from(name + (directory ? "/" : ""));
    const compressed = directory ? contents : deflateRawSync(contents);
    const method = directory ? 0 : 8;
    const checksum = crc32(contents);
    const header = Buffer.alloc(30);
    header.writeUInt32LE(0x04034b50, 0);
    header.writeUInt16LE(20, 4);
    header.writeUInt16LE(0x800, 6);
    header.writeUInt16LE(method, 8);
    header.writeUInt16LE(33, 12); // 1980-01-01, deterministic DOS date
    header.writeUInt32LE(checksum, 14);
    header.writeUInt32LE(compressed.length, 18);
    header.writeUInt32LE(contents.length, 22);
    header.writeUInt16LE(filename.length, 26);
    local.push(header, filename, compressed);
    const record = Buffer.alloc(46);
    record.writeUInt32LE(0x02014b50, 0);
    record.writeUInt16LE(0x0314, 4);
    header.copy(record, 6, 4, 30);
    const mode = directory ? 0o040755 : entry.executable ? 0o100755 : 0o100644;
    record.writeUInt32LE(((mode << 16) | (directory ? 0x10 : 0)) >>> 0, 38);
    record.writeUInt32LE(offset, 42);
    central.push(record, filename);
    centralSize += record.length + filename.length;
    offset += header.length + filename.length + compressed.length;
  }
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(entries.length, 8);
  end.writeUInt16LE(entries.length, 10);
  end.writeUInt32LE(centralSize, 12);
  end.writeUInt32LE(offset, 16);
  return Buffer.concat([...local, ...central, end]);
}

async function pack() {
  parseArgs({ options: {} });
  const [spec, generation, source] = await Promise.all([
    readJson("project-spec.json"), readJson("generation-manifest.json"),
    readJson("application.manifest.json"),
  ]);
  let built;
  const entries = [];
  const files = await readBuildFiles((name, contents, entry) => {
    if (name === "application.manifest.json") built = JSON.parse(contents.toString("utf8"));
    entries.push([name, contents, entry]);
  });
  if (!built || files[built.entrypoint]?.kind !== "file") throw new Error("PACKAGE_BUILD_INCOMPLETE");
  const manifestError = applicationManifestError(built);
  if (manifestError) throw new Error(manifestError);
  if (built.applicationId !== spec.applicationId || built.applicationId !== generation.applicationId ||
      !isDeepStrictEqual(built, source)) throw new Error("APPLICATION_IDENTITY_MISMATCH");
  await assertBuildInventory(files);
  // Windows local ZIP extraction rejects links; keep the default package portable.
  if (entries.some(([, , entry]) => entry.kind === "link")) throw new Error("PACKAGE_LINK_UNSUPPORTED");
  const archive = zip(entries);
  await mkdir("local-packages", { recursive: true });
  if (!(await lstat("local-packages")).isDirectory()) throw new Error("PACKAGE_UNSAFE_ENTRY");
  const output = path.join("local-packages", `${built.applicationId}-${built.version}.zip`);
  const handle = await open(output, "wx");
  try {
    await handle.writeFile(archive);
  } catch (error) {
    await handle.close();
    await unlink(output);
    throw error;
  }
  await handle.close();
  console.log(JSON.stringify({ package: output, sha256: createHash("sha256").update(archive).digest("hex"),
    installation: "not-run", host: "not-run" }, null, 2));
}

try {
  await pack();
} catch (error) {
  const messages = {
    ...applicationManifestMessages,
    APPLICATION_IDENTITY_MISMATCH: "应用标识或源码与构建清单不一致，请重新构建",
    PACKAGE_BUILD_INCOMPLETE: "构建缺失、已更改或不完整，请重新构建",
    PACKAGE_SIZE_LIMIT: "构建超过文件数量或大小上限",
    PACKAGE_UNSAFE_ENTRY: "构建或输出路径含不安全的条目",
    PACKAGE_LINK_UNSUPPORTED: "跨平台本地 ZIP 不包含符号链接，请调整生产依赖布局后重建",
    PACKAGE_OUTPUT_EXISTS: "同版本本地包已存在；更新应用版本或保留并移走旧包后重试",
    PACKAGE_ARGUMENTS_INVALID: "本地打包不需要参数，运行 npm run package",
    PACKAGE_FAILED: "无法生成本地安装 ZIP",
  };
  const code = error.code === "ENOENT" || error instanceof SyntaxError ? "PACKAGE_BUILD_INCOMPLETE"
    : error.code === "EEXIST" ? "PACKAGE_OUTPUT_EXISTS"
    : error.code?.startsWith("ERR_PARSE_ARGS_") ? "PACKAGE_ARGUMENTS_INVALID" : error.message;
  const known = Object.hasOwn(messages, code) ? code : "PACKAGE_FAILED";
  console.error(known + "：" + messages[known]);
  process.exitCode = 1;
}
