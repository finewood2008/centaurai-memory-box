import { spawnSync } from "node:child_process";
import { constants } from "node:fs";
import os from "node:os";
import { applicationManifestError, applicationManifestMessages } from "./application-manifest.mjs";
import { inventoryName, readBuildFiles } from "./build-files.mjs";
import path from "node:path";
import { isDeepStrictEqual } from "node:util";
import {
  copyFile,
  readFile,
  readdir,
  lstat,
  mkdir,
  mkdtemp,
  realpath,
  readlink,
  rm,
  rmdir,
  symlink,
  unlink,
  open,
} from "node:fs/promises";

const files = [
  "host.html",
  "host.mjs",
];
const hostFiles = ["shell/main.cjs", "shell/host.cjs", "shell/preload.cjs"];

async function build(expertProfile) {
  await mkdir("dist");
  const written = [],
    directories = [];
  let staging;
  async function copy(source, destination, dependencyRoot) {
    const info = await lstat(source);
    if (info.isDirectory()) {
      await mkdir(destination);
      directories.push(destination);
      for (const name of await readdir(source))
        await copy(source + "/" + name, destination + "/" + name, dependencyRoot);
    } else if (info.isFile()) {
      await copyFile(source, destination, constants.COPYFILE_EXCL);
      written.push(destination);
    } else if (info.isSymbolicLink() && dependencyRoot) {
      const declared = path.resolve(path.dirname(source), await readlink(source));
      const declaredRelative = path.relative(dependencyRoot, declared);
      if (declaredRelative === ".." || declaredRelative.startsWith(".." + path.sep) || path.isAbsolute(declaredRelative)) {
        throw new Error("BUILD_UNSAFE_DEPENDENCY_LINK");
      }
      let target;
      try {
        target = await realpath(source);
      } catch {
        throw new Error("BUILD_UNSAFE_DEPENDENCY_LINK");
      }
      const relative = path.relative(dependencyRoot, target);
      if (relative === ".." || relative.startsWith(".." + path.sep) || path.isAbsolute(relative)) {
        throw new Error("BUILD_UNSAFE_DEPENDENCY_LINK");
      }
      const parent = await realpath(path.dirname(source));
      await symlink(path.relative(parent, target), destination);
      written.push(destination);
    } else throw new Error("BUILD_UNSAFE_ENTRY");
  }
  try {
    for (const entry of [
      "app",
      "shell",
      "application.manifest.json",
      "package.json",
      "package-lock.json",
    ]) {
      await copy(entry, "dist/" + entry);
    }
    if (expertProfile) {
      await mkdir("dist/integration");
      directories.push("dist/integration");
      await copy("integration/selection.json", "dist/integration/selection.json");
    }
    // Install the production graph separately; never prune the developer's working tree.
    staging = await mkdtemp(path.join(os.tmpdir(), "wanx-build-"));
    for (const entry of ["package.json", "package-lock.json", "vendor"]) {
      await copy(entry, path.join(staging, entry));
    }
    const args = ["ci", "--omit=dev", "--ignore-scripts", "--no-audit", "--no-fund"];
    const installed = process.env.npm_execpath
      ? spawnSync(process.execPath, [process.env.npm_execpath, ...args], {cwd: staging, stdio: "ignore"})
      : spawnSync("npm", args, {cwd: staging, stdio: "ignore"});
    if (installed.status !== 0) throw new Error("BUILD_PRODUCTION_DEPENDENCIES_FAILED");
    const dependencyRoot = await realpath(path.join(staging, "node_modules"));
    await copy(dependencyRoot, "dist/node_modules", dependencyRoot);
    const inventory = await readBuildFiles();
    const inventoryFile = path.join("dist", inventoryName);
    const marker = await open(inventoryFile, "wx");
    written.push(inventoryFile);
    try {
      await marker.writeFile(JSON.stringify(inventory, null, 2) + "\n");
    } finally {
      await marker.close();
    }
  } catch (error) {
    await Promise.allSettled(written.map((file) => unlink(file)));
    for (const directory of directories.reverse())
      await rmdir(directory).catch(() => {});
    await rmdir("dist").catch(() => {});
    throw error;
  } finally {
    if (staging) await rm(staging, {recursive: true, force: true});
  }
}

async function run(mode) {
  if (mode !== "check" && mode !== "build") return "LOCAL_MODE_INVALID";
  const spec = JSON.parse(await readFile("project-spec.json", "utf8"));
  const generation = JSON.parse(
    await readFile("generation-manifest.json", "utf8"),
  );
  const application = JSON.parse(
    await readFile("application.manifest.json", "utf8"),
  );
  if (
    application.applicationId !== spec.applicationId ||
    spec.applicationId !== generation.applicationId
  ) {
    return "APPLICATION_IDENTITY_MISMATCH";
  }
  if (!(await lstat("app")).isDirectory()) return "APP_DIRECTORY_INVALID";
  for (const file of files) {
    const source = "app/" + file;
    if (!(await lstat(source)).isFile()) return "APP_FILE_INVALID " + source;
  }
  async function checkSources(directory) {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const source = directory + "/" + entry.name;
      if (entry.isDirectory()) {
        const error = await checkSources(source);
        if (error) return error;
      } else if (!entry.isFile()) return "APP_FILE_INVALID " + source;
      else if (/\.(?:js|mjs|cjs)$/.test(entry.name) &&
        spawnSync(process.execPath, ["--check", source], {stdio:"ignore"}).status !== 0) {
        return "APP_SYNTAX_INVALID " + source;
      }
    }
  }
  const sourceError = await checkSources("app");
  if (sourceError) return sourceError;
  for (const file of hostFiles) {
    if (!(await lstat(file)).isFile()) return "HOST_FILE_INVALID";
    if (
      spawnSync(process.execPath, ["--check", file], { stdio: "ignore" })
        .status !== 0
    )
      return "HOST_SYNTAX_INVALID";
  }
  if (spec.backend.mode !== "none") {
    try {
      const selection = "integration/selection.json";
      const guide = "integration/README.md";
      if (!(await lstat("integration")).isDirectory() ||
          !(await lstat(selection)).isFile() ||
          !(await lstat(guide)).isFile() ||
          !(await readFile(guide, "utf8")).trim() ||
          !isDeepStrictEqual(JSON.parse(await readFile(selection, "utf8")), spec.backend)) {
        return "INTEGRATION_SELECTION_INVALID";
      }
    } catch {
      return "INTEGRATION_SELECTION_INVALID";
    }
  }
  const expertProfile = spec.backend.mode === "existing" && spec.backend.connectionRef === "wanx.expert-app.v1";
  if (expertProfile) {
    const contracts = application.compatibility?.backendContracts;
    const declared = Array.isArray(contracts) ? contracts.filter(contract => contract?.id === "wanx.expert-app.v1") : [];
    if (!Array.isArray(declared) || declared.length !== 1 ||
        declared[0].range !== ">=1.0.0 <2.0.0" || !Array.isArray(declared[0].features) ||
        declared[0].features.length !== 3 || !["context", "expert", "data"].every(feature => declared[0].features.includes(feature))) {
      return "EXPERT_BACKEND_CONTRACT_REQUIRED";
    }
  }
  if (spec.expert.enabled) {
    const validator = "expert/validate.mjs";
    if (!(await lstat(validator)).isFile() ||
        spawnSync(process.execPath, ["--check", validator], { stdio: "ignore" }).status !== 0) {
      return "OPTIONAL_SOURCE_INVALID";
    }
    const { validDefinition } = await import("../expert/validate.mjs");
    const definition = JSON.parse(
      await readFile("expert/definition.json", "utf8"),
    );
    if (
      !validDefinition(definition) ||
      definition.definitionRef !== spec.expert.definitionRef
    )
      return "EXPERT_DEFINITION_INVALID";
    for (const file of [
      "expert/instructions.md",
      "expert/skills/service-use/SKILL.md",
    ])
      if (
        !(await lstat(file)).isFile() ||
        !(await readFile(file, "utf8")).trim()
      )
        return "EXPERT_SOURCE_INVALID";
  }
  // Resolve real SDK and its transitive dependencies before claiming readiness.
  if (
    spawnSync(process.execPath, ["-e", "require('@centaurai/wanx-host-sdk')"], {
      stdio: "ignore",
    }).status !== 0
  )
    return "HOST_DEPENDENCIES_MISSING_RUN_NPM_CI";
  const manifestError = applicationManifestError(application);
  if (manifestError) return manifestError;
  if (mode === "build") await build(expertProfile);
  console.log(
    "Local " + mode + ": PASS (WANX client Host SDK; install ZIP in WANX to run)",
  );
}

const buildErrors = new Set([
  "BUILD_PRODUCTION_DEPENDENCIES_FAILED",
  "BUILD_UNSAFE_DEPENDENCY_LINK",
  "BUILD_UNSAFE_ENTRY",
  "PACKAGE_SIZE_LIMIT",
  "PACKAGE_UNSAFE_ENTRY",
]);
const errorCode = await run(process.argv[2]).catch((error) => {
  if (error.code === "EEXIST") return "DIST_EXISTS";
  if (error.code === "MODULE_NOT_FOUND") return "HOST_DEPENDENCIES_MISSING_RUN_NPM_CI";
  return buildErrors.has(error.message) ? error.message : "LOCAL_CHECK_OR_BUILD_FAILED";
});
if (errorCode) {
  const message = applicationManifestMessages[errorCode];
  console.error(message ? errorCode + "：" + message : errorCode);
  process.exitCode = 1;
}
