import { createHash } from "node:crypto";
import { lstat, open, readFile, readdir, readlink, realpath } from "node:fs/promises";
import { constants } from "node:fs";
import path from "node:path";
import { isDeepStrictEqual } from "node:util";

export const inventoryName = ".build-inventory.json";
const byteLimit = 128 * 1024 * 1024;
const entryLimit = 10000;
const privateName = /^(?:\.env(?:\..*)?|\.npmrc|\.git(?:config|modules)?|\.netrc|\.pypirc|\.ssh|\.aws|id_(?:rsa|dsa|ecdsa|ed25519)|credentials(?:\..*)?|secrets?(?:\..*)?)$|\.(?:pem|key|p12|pfx)$/i;
const unsafeName = /[<>:"\\|?*\u0000-\u001f]|[ .]$/u;
const deviceName = /^(?:con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])(?:\.|$)/iu;

export async function readBuildFiles(consume) {
  if (!(await lstat("dist")).isDirectory()) throw new Error("PACKAGE_UNSAFE_ENTRY");
  const root = await realpath("dist");
  const dependencies = path.join(root, "node_modules");
  const inventory = new Map();
  const names = new Set();
  const directoryEdges = new Map([[root, []]]);
  let total = 0;

  async function visit(source, name) {
    const portableName = name.normalize("NFC").toLowerCase();
    const basename = path.basename(source);
    if ([".wanx-install.json", ".ds_store"].includes(basename.toLowerCase()) ||
        portableName === "__macosx" || privateName.test(basename) || unsafeName.test(basename) ||
        deviceName.test(basename) || names.has(portableName)) {
      throw new Error("PACKAGE_UNSAFE_ENTRY");
    }
    names.add(portableName);
    if (names.size > entryLimit || Buffer.byteLength(name) > 4096) {
      throw new Error("PACKAGE_SIZE_LIMIT");
    }
    const info = await lstat(source);
    const parent = path.dirname(source);
    if (info.isSymbolicLink()) {
      const reference = await readlink(source);
      const declared = path.resolve(parent, reference);
      const target = await realpath(source).catch(() => "");
      if (!name.startsWith("node_modules/") || path.isAbsolute(reference) ||
          !declared.startsWith(dependencies + path.sep) ||
          !target.startsWith(dependencies + path.sep)) {
        throw new Error("PACKAGE_UNSAFE_ENTRY");
      }
      const targetInfo = await lstat(target);
      if (!targetInfo.isDirectory() && !targetInfo.isFile()) throw new Error("PACKAGE_UNSAFE_ENTRY");
      const relative = path.relative(parent, target).split(path.sep).join("/");
      if (!relative || Buffer.byteLength(relative) > 4096 || /[\\:\u0000-\u001f]/u.test(relative)) {
        throw new Error("PACKAGE_UNSAFE_ENTRY");
      }
      const metadata = { kind: "link", target: relative, targetKind: targetInfo.isDirectory() ? "directory" : "file" };
      if (targetInfo.isDirectory()) directoryEdges.get(parent).push(target);
      inventory.set(name, metadata);
      await consume?.(name, Buffer.from(relative), metadata);
      return;
    }
    if (info.isDirectory()) {
      directoryEdges.get(parent).push(source);
      directoryEdges.set(source, []);
      const metadata = { kind: "directory" };
      inventory.set(name, metadata);
      await consume?.(name, Buffer.alloc(0), metadata);
      for (const child of (await readdir(source)).sort()) {
        await visit(path.join(source, child), name + "/" + child);
      }
      return;
    }
    if (!info.isFile()) throw new Error("PACKAGE_UNSAFE_ENTRY");

    const file = await open(source, constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0));
    try {
      const metadata = await file.stat();
      if (!metadata.isFile()) throw new Error("PACKAGE_UNSAFE_ENTRY");
      total += metadata.size;
      if (total > byteLimit) throw new Error("PACKAGE_SIZE_LIMIT");
      const contents = Buffer.alloc(metadata.size);
      let offset = 0;
      while (offset < contents.length) {
        const { bytesRead } = await file.read(contents, offset, contents.length - offset);
        if (bytesRead === 0) throw new Error("PACKAGE_BUILD_INCOMPLETE");
        offset += bytesRead;
      }
      if ((await file.stat()).size !== metadata.size) throw new Error("PACKAGE_BUILD_INCOMPLETE");
      const entry = {
        kind: "file",
        sha256: createHash("sha256").update(contents).digest("hex"),
        executable: Boolean(metadata.mode & 0o111),
      };
      inventory.set(name, entry);
      await consume?.(name, contents, entry);
    } finally {
      await file.close();
    }
  }

  for (const name of (await readdir(root)).sort()) {
    if (name !== inventoryName) await visit(path.join(root, name), name);
  }
  // Directory links add edges to the physical tree. Check them once instead
  // of recursively following every alias through the same dependency graph.
  const active = new Set();
  const checked = new Set();
  function checkDirectory(directory) {
    if (active.has(directory) || !directoryEdges.has(directory)) throw new Error("PACKAGE_UNSAFE_ENTRY");
    if (checked.has(directory)) return;
    active.add(directory);
    for (const child of directoryEdges.get(directory)) checkDirectory(child);
    active.delete(directory);
    checked.add(directory);
  }
  checkDirectory(root);
  return Object.fromEntries(inventory);
}


export async function assertBuildInventory(files) {
  const marker = path.join("dist", inventoryName);
  try {
    if (!(await lstat(marker)).isFile()) throw new Error("PACKAGE_UNSAFE_ENTRY");
    const expected = JSON.parse(await readFile(marker, "utf8"));
    if (isDeepStrictEqual(expected, files)) return;
  } catch (error) {
    if (error.code !== "ENOENT" && !(error instanceof SyntaxError)) throw error;
  }
  throw new Error("PACKAGE_BUILD_INCOMPLETE");
}
