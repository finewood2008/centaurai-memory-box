# 万象本地应用

应用运行在客户端共享 Electron 运行时，入口为 shell/main.cjs。主进程通过官方 Host SDK 复用客户端的盒子连接；页面通过 preload 的窄接口访问业务。

## 构建和本地安装

需要 Node.js 22.12+ 与 npm：

```sh
npm ci --ignore-scripts
npm run check
npm run build
npm run package
```

在 `local-packages/` 获取 `<applicationId>-<version>.zip`，输出包含 SHA-256。无需签名工具或密钥。ZIP 根目录保留 `application.manifest.json`；协议为 3，不设置 releaseAccess。

通过支持本地导入的万象客户端选择 ZIP、确认安装，连接盒子并打开应用，验证真实业务。缺少可见导入入口时向平台反馈客户端能力缺口，不要求取得平台源码或操作内部 IPC。package 成功仅表示生成包，不能替代安装验收。

修改后递增 application.manifest.json 的版本，保留 applicationId。先移走旧 dist（例如 `mv dist dist-previous`，目标名称须空闲），再 check/build/package 和重新安装。客户端拒绝同版本或降级安装，工具拒绝覆盖已有 ZIP。首次依赖安装和构建需要 registry 或缓存。

当前本地 ZIP 不支持自动准备 compatibility.resourceDependencies，check 会明确报错。可以编写专家草稿或按公开 API 使用已授权专家，但不能宣称已完成自动绑定。盒端自建服务需要 Bridge 注册；当前通用注册尚不可用，生成的 integration 仅记录计划。

## 从万象客户端运行

应用必须从万象客户端打开，由客户端提供共享 Electron 运行时与 Host 会话。套件不提供模拟 Host、浏览器 Mock 或独立 Electron 预览。缺少 Host 会话时启动退出并提示“请从万象客户端打开应用”。

页面为 app/host.html，骨架通过官方 SDK 调用 context() 和 drive.list()。preload 暴露 context、列文件、固定专家方法和失效事件；专家方法仅在清单与 integration/selection.json 同时声明 wanx.expert-app.v1 时允许调用。会话失效后清空页面并阻止旧结果回填。界面与业务测试均在客户端安装后执行。

## 实现业务

模板只是空间读取骨架，需实现用户要求的页面、数据操作、错误与相应测试。外部 API 按服务合同接入；需求包含自建后端时，可在独立服务项目实现，技术栈自行选择。应用和服务仅消费公共接口，不依赖平台内部模块。ProjectSpec 中的服务和专家引用不代表已部署或授权。

## 固定专家后端

当 ProjectSpec 的 backend 为 `{"mode":"existing","connectionRef":"wanx.expert-app.v1"}` 时，生成器声明版本范围 `>=1.0.0 <2.0.0` 和 context/expert/data 特性，构建保留该服务选择。expert.enabled 可保持 false，不选择全局专家或自动绑定资源。页面使用 `window.wanx.expertContext()` 与 `window.wanx.expertInvoke({operation,input})`，均返回 `{ok:true,value}` 或 `{ok:false,code}`。

允许操作仅 expert.run、expert.tasks、expert.cancel、data.list、data.get、data.put、data.delete。run 输入为 `{operationId,text}`，operationId 为32位小写十六进制，text 为非空白的1–12000字符；任务查询和取消使用runId。数据固定 collection=state、value={json:string}，写入和删除支持 expectedRevision。开发时查阅套件公开指南“固定专家后端应用”的完整字段与大小限制。页面不传 profile、URL、身份、环境、Token 或 Agent；会话失效时清空旧结果，后端变更须显示真实错误。

## Default reference UI

The starter is a reference workspace with sidebar navigation, a page header, list/detail and task examples. It is not an immutable layout. The confirmed PRD may replace navigation, page structure, styles and business content, including removing optional example pages. `app/host.html` and `app/host.mjs` remain launch entries. Other app files are editable/removable; use local relative imports and linked CSS that satisfies the delivered CSP. Platform shell, SDK, identity and permission contracts remain controlled by the host.

Template provenance is recorded as `uiTemplate` in the generation manifest. On an iteration preserve the actual application sources, not a fresh copy of the template. The task page is an empty layout example; it does not submit invented expert operations. Generate real expert inputs and behavior from the public host contract and the PRD.
