export function element(tag, text, className) {
  const node = document.createElement(tag);
  if (text != null) node.textContent = text;
  if (className) node.className = className;
  return node;
}
export function emptyState(title, description) {
  const panel = element('div', null, 'empty-state');
  panel.append(element('h2', title), element('p', description));
  return panel;
}
