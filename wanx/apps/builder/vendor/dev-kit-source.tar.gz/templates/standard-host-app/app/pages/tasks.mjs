import { element, emptyState } from '../ui.mjs';
// Layout example only. Generate actual expert inputs/actions from the PRD
// and rendererBridgeContract; do not invent an endpoint or simulated results.
export function showTasks({ content }) {
  const layout = element('div', null, 'task-layout'), workspace = element('section', null, 'panel'), side = element('aside', null, 'panel');
  workspace.append(emptyState('尚未配置任务', '当前应用未配置可执行任务。'));
  side.append(element('h2', '执行记录'), element('p', '任务执行后，在此查看状态和结果。'));
  layout.append(workspace, side); content.append(layout);
}
