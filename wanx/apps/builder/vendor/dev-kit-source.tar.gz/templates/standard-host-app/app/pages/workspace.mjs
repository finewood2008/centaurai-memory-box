import { element, emptyState } from '../ui.mjs';
export function showWorkspace({ content, actions, ready, active }) {
  const refresh = element('button', '刷新', 'primary');
  refresh.type = 'button'; refresh.disabled = !ready; actions.append(refresh);
  content.append(emptyState('工作台', ready ? '读取盒子空间中的文件，查看名称与详情。' : '连接万象后，可在此查看真实数据。'));
  refresh.addEventListener('click', async () => {
    refresh.disabled = true; content.replaceChildren(emptyState('正在加载', '请稍候…'));
    try {
      const response = await window.wanx.listFiles();
      if (!active()) return;
      if (!response.ok) { content.replaceChildren(emptyState('读取失败', '请稍后点击刷新重试。')); return; }
      const value = response.value;
      const rows = Array.isArray(value) ? value : value?.items || value?.files || [];
      if (!Array.isArray(rows) || !rows.length) { content.replaceChildren(emptyState('暂无文件', '添加文件后，可在这里刷新查看。')); return; }
      const layout = element('div', null, 'detail-layout'), list = element('section', null, 'panel record-list'), detail = element('section', null, 'panel');
      detail.append(emptyState('文件详情', '选择左侧文件查看。'));
      for (const row of rows) {
        const button = element('button', typeof row === 'string' ? row : row?.name || row?.title || '未命名文件', 'record');
        button.type = 'button';
        button.addEventListener('click', () => { detail.replaceChildren(element('h2', button.textContent), element('pre', JSON.stringify(row, null, 2))); });
        list.append(button);
      }
      layout.append(list, detail); content.replaceChildren(layout);
    } catch {
      if (active()) content.replaceChildren(emptyState('读取失败', '请稍后点击刷新重试。'));
    } finally {
      if (active()) refresh.disabled = false;
    }
  });
}
