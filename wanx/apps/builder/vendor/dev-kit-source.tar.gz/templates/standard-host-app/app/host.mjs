// Default reference only. The PRD may replace navigation, pages and layout.
import { showWorkspace } from './pages/workspace.mjs';
import { showTasks } from './pages/tasks.mjs';
import { showSettings } from './pages/settings.mjs';
const content = document.getElementById('content'), status = document.getElementById('status'),
  notice = document.getElementById('notice'), actions = document.getElementById('page-actions'), title = document.getElementById('page-title');
const pages = {
  workspace: { title: '工作台', render: showWorkspace },
  tasks: { title: '任务', render: showTasks },
  settings: { title: '设置', render: showSettings },
};
let current = 'workspace', epoch = 0, ready = false, revoked = false;
function render() {
  const generation = ++epoch;
  title.textContent = pages[current].title;
  actions.replaceChildren(); content.replaceChildren();
  for (const button of document.querySelectorAll('[data-page]')) {
    if (button.dataset.page === current) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  }
  pages[current].render({ content, actions, ready, active: () => generation === epoch && !revoked });
}
for (const button of document.querySelectorAll('[data-page]')) {
  button.addEventListener('click', () => { current = button.dataset.page; render(); });
}
window.wanx.onInvalidated(() => {
  revoked = true; ready = false; epoch++;
  status.textContent = '连接已失效'; notice.textContent = '请从万象重新打开应用后继续使用。'; notice.hidden = false; render();
});
render();
try {
  const context = await window.wanx.context();
  if (!revoked) {
    ready = context.ok; status.textContent = ready ? '已连接万象' : '尚未连接';
    if (!ready) { notice.textContent = '请从万象打开应用。布局预览不连接业务数据。'; notice.hidden = false; }
    render();
  }
} catch {
  if (!revoked) { status.textContent = '连接失败'; notice.textContent = '请重新打开应用后重试。'; notice.hidden = false; }
}
