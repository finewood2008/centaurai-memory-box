import { element } from '../ui.mjs';
export function showSettings({ content, ready }) {
  const panel = element('section', null, 'panel');
  panel.append(element('h2', '应用连接'), element('p', ready ? '已沿用当前万象会话。' : '尚未连接万象。'), element('p', '应用数据和授权由当前账号及运行环境管理。'));
  content.append(panel);
}
