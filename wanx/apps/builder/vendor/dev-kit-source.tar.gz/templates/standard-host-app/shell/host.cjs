const fs = require("node:fs");
const path = require("node:path");
const fail = (code) => Object.assign(new Error(code), { code });
const stableCode = (code) => typeof code === "string" && /^[A-Z][A-Z0-9_]{1,95}$/.test(code);
const plain = value => value !== null && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
const fields = (value, required, optional = []) => plain(value) && required.every(k => Object.hasOwn(value, k)) && Object.keys(value).every(k => required.includes(k) || optional.includes(k));
const runId = value => typeof value === "string" && /^[0-9a-f]{32}$/.test(value);
function validInvoke(value) {
  if (!fields(value, ["operation", "input"])) return false;
  const input = value.input;
  if (value.operation === "expert.run") return fields(input, ["operationId", "text"]) && runId(input.operationId) && typeof input.text === "string" && input.text.trim().length > 0 && Array.from(input.text).length <= 12000;
  if (value.operation === "expert.tasks") return fields(input, [], ["runId"]) && (!Object.hasOwn(input, "runId") || runId(input.runId));
  if (value.operation === "expert.cancel") return fields(input, ["runId"]) && runId(input.runId);
  const revision = () => !Object.hasOwn(input, "expectedRevision") || (Number.isSafeInteger(input.expectedRevision) && input.expectedRevision >= 0);
  if (value.operation === "data.list") return fields(input, ["collection"], ["offset", "limit"]) && input.collection === "state" &&
    (!Object.hasOwn(input, "offset") || (Number.isSafeInteger(input.offset) && input.offset >= 0)) &&
    (!Object.hasOwn(input, "limit") || (Number.isSafeInteger(input.limit) && input.limit >= 1 && input.limit <= 200));
  const id = () => input.collection === "state" && typeof input.id === "string" && Array.from(input.id).length >= 1 && Array.from(input.id).length <= 128;
  if (value.operation === "data.get") return fields(input, ["collection", "id"]) && id();
  if (value.operation === "data.delete") return fields(input, ["collection", "id"], ["expectedRevision"]) && id() && revision();
  if (value.operation === "data.put") return fields(input, ["collection", "id", "value"], ["expectedRevision"]) && id() && revision() &&
    fields(input.value, ["json"]) && typeof input.value.json === "string" && Buffer.byteLength(JSON.stringify(input.value), "utf8") <= 262144;
  return false;
}
function expertEnabled() {
  try {
    const manifest = JSON.parse(fs.readFileSync(path.join(__dirname, "../application.manifest.json"), "utf8"));
    const selection = JSON.parse(fs.readFileSync(path.join(__dirname, "../integration/selection.json"), "utf8"));
    const contracts = manifest.compatibility?.backendContracts;
    const matches = Array.isArray(contracts) ? contracts.filter(c => c.id === "wanx.expert-app.v1") : [];
    return selection.mode === "existing" && selection.connectionRef === "wanx.expert-app.v1" && Object.keys(selection).length === 2 &&
      matches.length === 1 && matches[0].range === ">=1.0.0 <2.0.0" && Array.isArray(matches[0].features) &&
      matches[0].features.length === 3 && ["context", "expert", "data"].every(f => matches[0].features.includes(f));
  } catch { return false; }
}
const { fromEnvironment } = require("@centaurai/wanx-host-sdk");
// Main-process only. No arbitrary URL/request bridge is exposed.
function createHostAdapter(env = process.env) {
  const host = fromEnvironment(env);
  if (!host) throw fail("HOST_SESSION_MISSING");
  let invalid = false,
    epoch = 0;
  const listeners = new Set();
  host.onSessionInvalidated(() => {
    invalid = true;
    epoch++;
    for (const listener of listeners) listener();
  });
  const enabled = expertEnabled();
  let initialized, expertInitialized;
  const run = async (operation) => {
    if (invalid) throw fail("HOST_SESSION_EXPIRED");
    const started = epoch;
    let result;
    try { result = await operation(); } catch (error) {
      if (invalid || started !== epoch) throw fail("HOST_SESSION_EXPIRED");
      throw error;
    }
    if (invalid || started !== epoch) throw fail("HOST_SESSION_EXPIRED");
    return result;
  };
  const expertRequest = async (route, options) => {
    if (!enabled) throw fail("EXPERT_BACKEND_CONTRACT_REQUIRED");
    await (initialized ||= host.context().catch(error => { initialized = undefined; throw error; }));
    const response = await host.request("/api/wanx-expert-app/v1/" + route, options);
    let body;
    try { body = await response.json(); } catch { throw fail("HOST_INVALID_RESPONSE"); }
    if (!response.ok) throw fail(stableCode(body?.code) ? body.code : "HOST_OPERATION_FAILED");
    return body;
  };
  const readExpertContext = async () => {
      const body = await expertRequest("context", { method: "GET" });
      if (!plain(body) || body.schemaVersion !== 1 || typeof body.scopeId !== "string" || !/^[0-9a-f]{64}$/.test(body.scopeId) ||
          !["dev", "prod"].includes(body.environment) || !Number.isSafeInteger(body.generation) || body.generation < 0 ||
          typeof body.artifactHash !== "string" || !/^[0-9a-f]{64}$/.test(body.artifactHash)) throw fail("HOST_INVALID_RESPONSE");
      const current = Object.fromEntries(["schemaVersion", "scopeId", "environment", "generation", "artifactHash"].map(key => [key, body[key]]));
      expertInitialized ||= Promise.resolve(current);
      return current;
  };
  return Object.freeze({
    context: () =>
      run(async () => {
        const c = await host.context();
        return { boxId: c.boxId, userId: c.user?.id, connection: c.connection };
      }),
    expertContext: () => run(readExpertContext),
    expertInvoke: (value) => run(async () => {
      if (!enabled) throw fail("EXPERT_BACKEND_CONTRACT_REQUIRED");
      let encoded;
      try { encoded = JSON.stringify(value); } catch { throw fail("HOST_REQUEST_REJECTED"); }
      if (!validInvoke(value) || !encoded || Buffer.byteLength(encoded, "utf8") > 270336) throw fail("HOST_REQUEST_REJECTED");
      await (expertInitialized ||= readExpertContext().catch(error => { expertInitialized = undefined; throw error; }));
      return expertRequest("invoke", { method: "POST", body: JSON.parse(encoded) });
    }),
    listFiles: () =>
      run(async () => {
        const data = await host.drive.list();
        return data;
      }),
    onInvalidated: (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    close: () => {
      invalid = true;
      epoch++;
      listeners.clear();
      host.close();
    },
  });
}
module.exports = { createHostAdapter };
