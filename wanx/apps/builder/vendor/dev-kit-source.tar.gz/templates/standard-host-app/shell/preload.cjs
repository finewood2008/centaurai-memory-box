const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld(
  "wanx",
  Object.freeze({
    context: () => ipcRenderer.invoke("wanx:context"),
    expertContext: () => ipcRenderer.invoke("wanx:expert-context"),
    expertInvoke: (request) => ipcRenderer.invoke("wanx:expert-invoke", request),
    listFiles: () => ipcRenderer.invoke("wanx:list-files"),
    onInvalidated: (callback) => {
      const listener = () => callback();
      ipcRenderer.on("wanx:invalidated", listener);
      return () => ipcRenderer.removeListener("wanx:invalidated", listener);
    },
  }),
);
