const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("node:path");
const { createHostAdapter } = require("./host.cjs");
let host;
try {
  host = createHostAdapter();
} catch {
  console.error("HOST_SESSION_REQUIRED：请从万象客户端打开应用");
  app.exit(1);
}
if (host) {
  app
    .whenReady()
    .then(() => {
      const window = new BrowserWindow({
        width: 900,
        height: 640,
        webPreferences: {
          preload: path.join(__dirname, "preload.cjs"),
          contextIsolation: true,
          nodeIntegration: false,
          sandbox: true,
        },
      });
      const trusted = (event) =>
        event.sender === window.webContents &&
        event.senderFrame === window.webContents.mainFrame;
      for (const [channel, operation, argumentCount] of [
        ["wanx:context", host.context, 0],
        ["wanx:list-files", host.listFiles, 0],
        ["wanx:expert-context", host.expertContext, 0],
        ["wanx:expert-invoke", host.expertInvoke, 1],
      ]) {
        ipcMain.handle(channel, async (event, ...args) => {
          if (!trusted(event) || args.length !== argumentCount)
            return { ok: false, code: "HOST_REQUEST_REJECTED" };
          try {
            return { ok: true, value: await operation(...args) };
          } catch (error) {
            const code = typeof error?.code === "string" && /^[A-Z][A-Z0-9_]{1,95}$/.test(error.code) ? error.code : "HOST_OPERATION_FAILED";
            return { ok: false, code };
          }
        });
      }
      window.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
      window.webContents.on("will-navigate", (event) => event.preventDefault());
      host.onInvalidated(() => {
        if (!window.isDestroyed()) window.webContents.send("wanx:invalidated");
      });
      window.loadFile(path.join(__dirname, "../app/host.html"));
    })
    .catch(() => app.exit(1));
  app.on("before-quit", () => host.close());
  app.on("window-all-closed", () => app.quit());
}
