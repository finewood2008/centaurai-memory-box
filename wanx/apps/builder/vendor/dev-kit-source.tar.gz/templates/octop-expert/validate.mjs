const safe = (value) =>
  typeof value === "string" &&
  value.length <= 160 &&
  /^[a-zA-Z0-9][a-zA-Z0-9_-]*(?:[./-][a-zA-Z0-9][a-zA-Z0-9_-]*)*$/.test(value);
export function validDefinition(value) {
  if (!value || Array.isArray(value) || typeof value !== "object") return false;
  const keys = [
    "schemaVersion",
    "status",
    "purpose",
    "instructions",
    "skills",
    "dependencyRefs",
    "definitionRef",
  ];
  return (
    Object.keys(value).length === keys.length &&
    keys.every((k) => Object.hasOwn(value, k)) &&
    value.schemaVersion === 1 &&
    value.status === "draft-local" &&
    typeof value.purpose === "string" &&
    value.purpose.trim().length > 0 &&
    value.purpose.length <= 2000 &&
    value.instructions === "instructions.md" &&
    safe(value.definitionRef) &&
    Array.isArray(value.skills) &&
    value.skills.length === 1 &&
    value.skills[0] === "skills/service-use/SKILL.md" &&
    Array.isArray(value.dependencyRefs) &&
    value.dependencyRefs.length <= 100 &&
    value.dependencyRefs.every(safe) &&
    new Set(value.dependencyRefs).size === value.dependencyRefs.length
  );
}
