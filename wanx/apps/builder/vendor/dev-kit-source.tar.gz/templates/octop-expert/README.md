# 本地专家源码

按应用需求修改 instructions.md 和 service-use Skill。definition.json 是本地草稿格式，由 definition.schema.json 和 validate.mjs 校验。平台专家 API 的请求字段由固定 Kit 的公开合同定义。dependencyRefs 记录证据引用，实际连接器使用平台已绑定的名称。

按目标版本的公开合同发布专家，将已发布资源填入协议 3 应用清单的 compatibility.resourceDependencies，并通过 Host SDK 获取绑定。创建 Agent 时，按需引用用户已授权的知识库或已绑定的 mcp_servers 名称。需要服务工具时，由相应服务项目提供实际接口或 MCP 连接器，并通过平台流程完成授权和绑定。验证应用／用户对路由的访问权限，并仅在预期作用域内保存返回的标识。接口缺失时向套件维护者报告，禁止修改平台专家运行时或复制其内部模块。
