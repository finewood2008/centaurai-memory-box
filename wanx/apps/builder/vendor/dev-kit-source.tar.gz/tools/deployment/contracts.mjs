import { readFileSync } from "node:fs";
import { createHash } from "node:crypto";
import Ajv from "ajv";

const base = "https://schemas.wanx.example/deployment/v1/";
const ajv = new Ajv({ allErrors: true, strict: true });
for (const name of ["common", "bundle", "request", "receipt"]) {
  const schema = JSON.parse(
    readFileSync(
      new URL(
        `../../contracts/deployment/v1/${name}.schema.json`,
        import.meta.url,
      ),
      "utf8",
    ),
  );
  ajv.addSchema(schema);
}
const schemas = Object.fromEntries(
  ["bundle", "request", "receipt"].map((name) => [
    name,
    ajv.getSchema(`${base}${name}.schema.json`),
  ]),
);
const deploymentKinds = new Set(["deploy", "promote", "rollback"]);
const successStatus = {
  deploy: "ready",
  promote: "ready",
  rollback: "ready",
  restart: "ready",
  recover: "ready",
  stop: "stopped",
  uninstall: "uninstalled",
  purge: "purged",
};
const diagnostic = (code, path) => ({ code, path });
const result = (errors) => ({ valid: errors.length === 0, errors });
const equal = (left, right) =>
  canonicalizeJson(left) === canonicalizeJson(right);

/** Local JSON profile, not RFC 8785. Safe integers only; keys sort by UTF-16 code units. */
export function canonicalizeJson(value) {
  let count = 0;
  const seen = new Set();
  function encode(item, depth) {
    if (++count > 100000 || depth > 64) throw new Error();
    if (item === null) return "null";
    if (typeof item === "boolean") return String(item);
    if (typeof item === "number") {
      if (!Number.isSafeInteger(item) || Object.is(item, -0)) throw new Error();
      return String(item);
    }
    if (typeof item === "string") {
      if (item.length > 1048576 || !item.isWellFormed()) throw new Error();
      return JSON.stringify(item);
    }
    if (typeof item !== "object" || seen.has(item)) throw new Error();
    const proto = Object.getPrototypeOf(item);
    if (!Array.isArray(item) && proto !== Object.prototype && proto !== null)
      throw new Error();
    const descriptors = Object.getOwnPropertyDescriptors(item);
    const keys = Reflect.ownKeys(descriptors);
    if (
      keys.some(
        (key) =>
          typeof key !== "string" ||
          "get" in descriptors[key] ||
          "set" in descriptors[key],
      )
    )
      throw new Error();
    seen.add(item);
    let output;
    if (Array.isArray(item)) {
      if (item.length > 100000 || keys.length !== item.length + 1)
        throw new Error();
      const parts = [];
      for (let i = 0; i < item.length; i++) {
        if (!descriptors[i]?.enumerable) throw new Error();
        parts.push(encode(descriptors[i].value, depth + 1));
      }
      output = `[${parts.join(",")}]`;
    } else {
      if (keys.some((key) => !descriptors[key].enumerable)) throw new Error();
      output = `{${keys
        .sort()
        .map((key) => {
          if (!key.isWellFormed()) throw new Error();
          return `${JSON.stringify(key)}:${encode(descriptors[key].value, depth + 1)}`;
        })
        .join(",")}}`;
    }
    seen.delete(item);
    return output;
  }
  try {
    return encode(value, 0);
  } catch {
    throw new Error("CANONICAL_JSON_INVALID");
  }
}
const digest = (value) =>
  `sha256:${createHash("sha256").update(canonicalizeJson(value), "utf8").digest("hex")}`;

/** Content identity excludes its own digest and the external provenance attestation reference. */
export function computeBundleDigest(bundle) {
  const value = JSON.parse(canonicalizeJson(bundle));
  if (!value || Array.isArray(value) || typeof value !== "object")
    throw new Error("BUNDLE_OBJECT_REQUIRED");
  delete value.bundleDigest;
  delete value.provenanceRef;
  return digest(value);
}
/** Includes all wire request fields. Trusted caller identity belongs to the external idempotency scope. */
export function computeRequestDigest(request) {
  return digest(request);
}

function structural(name, value) {
  try {
    canonicalizeJson(value);
  } catch {
    return [diagnostic("JSON_PROFILE_INVALID", `/${name}`)];
  }
  if (schemas[name](value)) return [];
  // Do not return AJV messages, params, data, instancePath, or unknown property names.
  // Inputs may contain secrets even where a contract forbids those fields.
  return [diagnostic(`${name.toUpperCase()}_SCHEMA_INVALID`, `/${name}`)];
}
function uniqueBy(values, key) {
  return new Set(values.map((value) => value[key])).size === values.length;
}

export function validateBundle(bundle) {
  const errors = structural("bundle", bundle);
  if (errors.length) return result(errors);
  if (computeBundleDigest(bundle) !== bundle.bundleDigest)
    errors.push(diagnostic("BUNDLE_DIGEST_MISMATCH", "/bundle/bundleDigest"));
  if (!uniqueBy(bundle.artifactDescriptors, "artifactId"))
    errors.push(
      diagnostic("DUPLICATE_ARTIFACT_ID", "/bundle/artifactDescriptors"),
    );
  if (
    bundle.artifactDescriptors.some(
      (artifact) =>
        artifact.sourceRef.digest &&
        artifact.sourceRef.digest !== artifact.digest,
    )
  )
    errors.push(
      diagnostic(
        "ARTIFACT_SOURCE_DIGEST_MISMATCH",
        "/bundle/artifactDescriptors",
      ),
    );
  const artifacts = new Map(
    bundle.artifactDescriptors.map((artifact) => [
      artifact.artifactId,
      artifact,
    ]),
  );
  if (
    bundle.clientDelivery.mode === "install" &&
    artifacts.get(bundle.clientDelivery.artifactId)?.role !== "client"
  )
    errors.push(
      diagnostic("CLIENT_ARTIFACT_REQUIRED", "/bundle/clientDelivery"),
    );
  if (
    bundle.clientDelivery.mode === "load" &&
    bundle.clientDelivery.resourceArtifactIds.some(
      (id) => !["client", "assets"].includes(artifacts.get(id)?.role),
    )
  )
    errors.push(
      diagnostic("CLIENT_RESOURCE_ARTIFACT_INVALID", "/bundle/clientDelivery"),
    );
  if (
    bundle.payloadKind === "managed-spec" &&
    bundle.specRef.digest &&
    bundle.specRef.digest !== bundle.specDigest
  )
    errors.push(diagnostic("SPEC_DIGEST_MISMATCH", "/bundle/specRef"));
  return result(errors);
}
export function validateRequest(request) {
  return result(structural("request", request));
}

export function validateReceipt(receipt) {
  const errors = structural("receipt", receipt);
  if (errors.length) return result(errors);
  if (
    !Number.isFinite(Date.parse(receipt.observedAt)) ||
    new Date(receipt.observedAt).toISOString() !== receipt.observedAt
  )
    errors.push(diagnostic("OBSERVED_AT_INVALID", "/receipt/observedAt"));
  if (!uniqueBy(receipt.componentResults, "componentId"))
    errors.push(
      diagnostic("DUPLICATE_COMPONENT_ID", "/receipt/componentResults"),
    );
  const required = receipt.componentResults.filter(
    (component) => component.required,
  );
  if (
    receipt.commitStatus !== "committed" &&
    receipt.committedGeneration !== null
  )
    errors.push(
      diagnostic("UNCONFIRMED_GENERATION", "/receipt/committedGeneration"),
    );
  if (
    receipt.commitStatus === "committed" &&
    (receipt.committedGeneration === null ||
      receipt.committedGeneration < receipt.previousGeneration)
  )
    errors.push(
      diagnostic(
        "COMMITTED_GENERATION_INVALID",
        "/receipt/committedGeneration",
      ),
    );
  if (deploymentKinds.has(receipt.kind) && receipt.requestedReleaseRef === null)
    errors.push(
      diagnostic("REQUESTED_RELEASE_REQUIRED", "/receipt/requestedReleaseRef"),
    );
  if (
    ["rejected", "failed_recovered"].includes(receipt.outcome) &&
    receipt.commitStatus !== "not_committed"
  )
    errors.push(
      diagnostic("PRECOMMIT_OUTCOME_INVALID", "/receipt/commitStatus"),
    );
  if (
    receipt.outcome === "failed_degraded" &&
    receipt.commitStatus !== "committed"
  )
    errors.push(
      diagnostic("DEGRADED_COMMIT_REQUIRED", "/receipt/commitStatus"),
    );
  if (
    receipt.commitStatus === "unknown" &&
    receipt.outcome !== "recovery_required"
  )
    errors.push(diagnostic("UNKNOWN_REQUIRES_RECOVERY", "/receipt/outcome"));
  if (
    deploymentKinds.has(receipt.kind) &&
    receipt.commitStatus === "committed" &&
    (receipt.previousGeneration === Number.MAX_SAFE_INTEGER ||
      receipt.committedGeneration !== receipt.previousGeneration + 1)
  )
    errors.push(
      diagnostic(
        "ACTIVATION_GENERATION_INVALID",
        "/receipt/committedGeneration",
      ),
    );
  if (receipt.kind === "recover" && receipt.recoveryOf === receipt.operationId)
    errors.push(diagnostic("RECOVERY_SELF_REFERENCE", "/receipt/recoveryOf"));
  if (receipt.commitStatus === "committed") {
    if (receipt.environmentRevision < 1)
      errors.push(
        diagnostic(
          "COMMITTED_ENVIRONMENT_REVISION_INVALID",
          "/receipt/environmentRevision",
        ),
      );
    for (const role of ["backend", "client"]) {
      if (required.filter((component) => component.role === role).length !== 1)
        errors.push(
          diagnostic(
            "REQUIRED_ROLE_MISSING_OR_DUPLICATE",
            "/receipt/componentResults",
          ),
        );
    }
    if (
      ["restart", "stop", "uninstall", "purge"].includes(receipt.kind) &&
      receipt.committedGeneration !== receipt.previousGeneration
    )
      errors.push(
        diagnostic(
          "MANAGEMENT_GENERATION_CHANGED",
          "/receipt/committedGeneration",
        ),
      );
  }
  if (receipt.outcome === "succeeded") {
    if (receipt.commitStatus !== "committed" || receipt.environmentRevision < 1)
      errors.push(
        diagnostic("SUCCESS_COMMIT_REQUIRED", "/receipt/commitStatus"),
      );
    if (
      !required.length ||
      required.some(
        (component) => component.status !== successStatus[receipt.kind],
      )
    )
      errors.push(
        diagnostic(
          "REQUIRED_COMPONENT_NOT_SUCCESSFUL",
          "/receipt/componentResults",
        ),
      );
    for (const component of required) {
      if (component.error)
        errors.push(
          diagnostic(
            "SUCCESS_COMPONENT_HAS_ERROR",
            "/receipt/componentResults",
          ),
        );
      if (
        successStatus[receipt.kind] === "ready" &&
        (!component.actualReleaseRef ||
          !component.actualVersion ||
          !receipt.requestedReleaseRef ||
          !equal(component.actualReleaseRef, receipt.requestedReleaseRef))
      )
        errors.push(
          diagnostic("COMPONENT_RELEASE_MISMATCH", "/receipt/componentResults"),
        );
    }
  }
  return result(errors);
}

/** Offline consistency only. context.requiredChannelIds must come from the resolved, trusted ChannelBindings. */
export function validateDeployment(input) {
  try {
    if (!input || typeof input !== "object" || Array.isArray(input))
      throw new Error();
    canonicalizeJson(input);
  } catch {
    return result([diagnostic("DEPLOYMENT_SET_INVALID", "/deployment")]);
  }
  const { bundle, request, receipt, context } = input;
  const errors = [
    ...validateBundle(bundle).errors,
    ...validateRequest(request).errors,
    ...validateReceipt(receipt).errors,
  ];
  let channels;
  try {
    const contextJson = canonicalizeJson(context);
    const parsed = JSON.parse(contextJson);
    channels = parsed.requiredChannelIds;
    if (
      Object.keys(parsed).length !== 1 ||
      !Array.isArray(channels) ||
      channels.length > 128 ||
      new Set(channels).size !== channels.length ||
      channels.some(
        (id) =>
          typeof id !== "string" ||
          id.length > 128 ||
          !/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(id),
      )
    )
      throw new Error();
  } catch {
    errors.push(diagnostic("RESOLVED_CHANNEL_CONTEXT_REQUIRED", "/context"));
  }
  if (errors.length) return result(errors);
  const expectedRelease = {
    releaseId: bundle.releaseId,
    bundleDigest: bundle.bundleDigest,
  };
  if (request.target.applicationId !== bundle.applicationId)
    errors.push(
      diagnostic("APPLICATION_MISMATCH", "/request/target/applicationId"),
    );
  if (request.releaseRef && !equal(request.releaseRef, expectedRelease))
    errors.push(diagnostic("REQUEST_RELEASE_MISMATCH", "/request/releaseRef"));
  if (
    receipt.requestedReleaseRef &&
    !equal(receipt.requestedReleaseRef, expectedRelease)
  )
    errors.push(
      diagnostic("RECEIPT_RELEASE_MISMATCH", "/receipt/requestedReleaseRef"),
    );
  if (!equal(request.target, receipt.target))
    errors.push(diagnostic("TARGET_MISMATCH", "/receipt/target"));
  if (request.kind !== receipt.kind)
    errors.push(diagnostic("KIND_MISMATCH", "/receipt/kind"));
  // A generation-conflict rejection may report a different actual generation; success may not.
  if (
    receipt.commitStatus === "committed" &&
    request.expectedGeneration !== receipt.previousGeneration
  )
    errors.push(
      diagnostic("EXPECTED_GENERATION_MISMATCH", "/receipt/previousGeneration"),
    );
  if (receipt.outcome === "succeeded") {
    const components = receipt.componentResults;
    const required = components.filter((component) => component.required);
    for (const role of ["backend", "client"])
      if (required.filter((component) => component.role === role).length !== 1)
        errors.push(
          diagnostic(
            "REQUIRED_ROLE_MISSING_OR_DUPLICATE",
            "/receipt/componentResults",
          ),
        );
    for (const id of channels)
      if (
        !required.some(
          (component) =>
            component.role === "channel" && component.componentId === id,
        )
      )
        errors.push(
          diagnostic("REQUIRED_CHANNEL_MISSING", "/receipt/componentResults"),
        );
    // The consumer must not silently omit a declared required channel from its resolved context.
    if (
      required.some(
        (component) =>
          component.role === "channel" &&
          !channels.includes(component.componentId),
      )
    )
      errors.push(
        diagnostic("CHANNEL_CONTEXT_MISMATCH", "/receipt/componentResults"),
      );
    if (
      successStatus[request.kind] === "ready" &&
      !equal(receipt.requestedReleaseRef, expectedRelease)
    )
      errors.push(
        diagnostic("RECEIPT_RELEASE_MISMATCH", "/receipt/requestedReleaseRef"),
      );
  }
  return result(errors);
}
