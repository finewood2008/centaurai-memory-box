import { readFile } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { resolve } from "node:path";
import {
  validateBundle,
  validateRequest,
  validateReceipt,
  validateDeployment,
  computeBundleDigest,
  computeRequestDigest,
} from "./contracts.mjs";
const validators = {
  bundle: validateBundle,
  request: validateRequest,
  receipt: validateReceipt,
};
const readJson = async (file) => JSON.parse(await readFile(file, "utf8"));

/** Validate repository-owned fixtures; no network or runtime execution. */
export async function validateSamples() {
  const root = new URL("../../examples/deployment/", import.meta.url);
  const manifest = await readJson(new URL("cases.json", root));
  const groups = ["bundle", "request", "receipt", "linked"];
  if (
    !manifest ||
    typeof manifest !== "object" ||
    Array.isArray(manifest) ||
    Object.keys(manifest).length !== groups.length ||
    groups.some(
      (key) =>
        !Object.hasOwn(manifest, key) ||
        !Array.isArray(manifest[key]) ||
        !manifest[key].length,
    )
  )
    throw new Error("SAMPLE_MANIFEST_INVALID");
  if (
    manifest.linked.some(
      (entry) =>
        !entry ||
        typeof entry !== "object" ||
        Array.isArray(entry) ||
        Object.keys(entry).length !== 4 ||
        ["bundle", "request", "receipt", "context"].some(
          (key) => !Object.hasOwn(entry, key),
        ),
    )
  )
    throw new Error("SAMPLE_MANIFEST_INVALID");
  const errors = [];
  let checked = 0;
  const readSample = (file) => {
    if (typeof file !== "string" || !/^[a-z0-9][a-z0-9.-]*\.json$/.test(file))
      throw new Error("SAMPLE_REFERENCE_INVALID");
    return readJson(new URL(file, root));
  };
  for (const [kind, validate] of Object.entries(validators)) {
    for (const file of manifest[kind]) {
      const validation = validate(await readSample(file));
      errors.push(
        ...validation.errors.map((error) => ({
          ...error,
          sampleIndex: checked,
        })),
      );
      checked++;
    }
  }
  for (const files of manifest.linked) {
    const [bundle, request, receipt, context] = await Promise.all(
      ["bundle", "request", "receipt", "context"].map((key) =>
        readSample(files[key]),
      ),
    );
    errors.push(
      ...validateDeployment({ bundle, request, receipt, context }).errors.map(
        (error) => ({ ...error, sampleIndex: checked }),
      ),
    );
    checked++;
  }
  return { valid: errors.length === 0, checked, errors };
}

export async function main(args) {
  const [command, ...files] = args;
  try {
    let output;
    if (command === "samples" && files.length === 0)
      output = await validateSamples();
    else if (Object.hasOwn(validators, command) && files.length === 1)
      output = validators[command](await readJson(files[0]));
    else if (command === "linked" && files.length === 4) {
      const [bundle, request, receipt, context] = await Promise.all(
        files.map(readJson),
      );
      output = validateDeployment({ bundle, request, receipt, context });
    } else if (
      ["digest-bundle", "digest-request"].includes(command) &&
      files.length === 1
    ) {
      const value = await readJson(files[0]);
      output = {
        digest:
          command === "digest-bundle"
            ? computeBundleDigest(value)
            : computeRequestDigest(value),
      };
    } else {
      console.error(
        "Usage: node tools/deployment/validate.mjs samples | bundle|request|receipt|digest-bundle|digest-request <file> | linked <bundle> <request> <receipt> <context>",
      );
      return 1;
    }
    console.log(JSON.stringify(output, null, 2));
    return output.valid === false ? 1 : 0;
  } catch {
    console.error("DEPLOYMENT_INPUT_READ_OR_JSON_INVALID");
    return 1;
  }
}
if (
  process.argv[1] &&
  resolve(process.argv[1]) === fileURLToPath(import.meta.url)
)
  process.exitCode = await main(process.argv.slice(2));
