// Import a delivered App Kit; no platform checkout or lock file is required.
import { mkdtemp, mkdir, rm, cp, lstat } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { checkKit } from "./check.mjs";
const source = process.argv[2];
if (!source) throw new Error("DELIVERED_KIT_DIRECTORY_REQUIRED");
const destination = new URL("../../vendor/wanx-app-kit/0.3.0/", import.meta.url);
if (await lstat(destination).catch(() => null)) throw new Error("KIT_OUTPUT_EXISTS");
const temporary = await mkdtemp(path.join(tmpdir(), "wanx-kit-import-"));
try {
  await cp(path.resolve(source), path.join(temporary, "0.3.0"), { recursive: true, verbatimSymlinks: true });
  await checkKit(temporary);
  await mkdir(destination);
  await cp(path.join(temporary, "0.3.0"), destination, { recursive: true, force: false, errorOnExist: true });
  console.log("App Kit imported: 0.3.0");
} finally {
  await rm(temporary, { recursive: true, force: true });
}
