import { readFile, readdir, lstat } from "node:fs/promises";
import { createHash } from "node:crypto";
import { gunzipSync } from "node:zlib";
import path from "node:path";
import { fileURLToPath } from "node:url";
const hash = (bytes) => createHash("sha256").update(bytes).digest("hex");
async function tree(root, relative = "") {
  if (!(await lstat(path.join(root, relative))).isDirectory())
    throw new Error("KIT_UNSAFE_DIRECTORY");
  const files = [];
  for (const entry of (await readdir(path.join(root, relative))).sort((a, b) =>
    a.localeCompare(b),
  )) {
    const name = relative ? relative + "/" + entry : entry;
    const stat = await lstat(path.join(root, name));
    if (stat.isDirectory()) files.push(...(await tree(root, name)));
    else if (stat.isFile()) files.push(name);
    else throw new Error("KIT_UNSAFE_ENTRY");
  }
  return files;
}
export async function checkKit(
  root = fileURLToPath(new URL("../../vendor/wanx-app-kit/", import.meta.url)),
) {
  const version = "0.3.0";
  const dir = path.join(root, version);
  if (!(await lstat(dir)).isDirectory() ||
      !(await lstat(path.join(dir, "wanx-app-kit.json"))).isFile())
    throw new Error("KIT_UNSAFE_ENTRY");
  const bytes = await readFile(path.join(dir, "wanx-app-kit.json"));
  const manifest = JSON.parse(bytes);
  if (manifest.kitVersion !== version || !Array.isArray(manifest.artifacts))
    throw new Error("KIT_MANIFEST_INVALID");
  const sdk = manifest.artifacts.find(artifact => artifact.kind === "sdk" && artifact.name === "@centaurai/wanx-host-sdk");
  if (!sdk || sdk.version !== version) throw new Error("KIT_SDK_INVALID");
  const safe = (value) =>
    typeof value === "string" &&
    !value.includes("\\") &&
    !path.isAbsolute(value) &&
    value.split("/").every((p) => p && p !== "." && p !== "..");
  if (!safe(sdk.packageFile) || sdk.packageFile.includes("/")) throw new Error("KIT_PATH_INVALID");
  const archiveFile = path.join(dir, sdk.packageFile);
  if (!(await lstat(archiveFile)).isFile()) throw new Error("KIT_UNSAFE_ENTRY");
  const archive = await readFile(archiveFile);
  for (const artifact of manifest.artifacts) {
    if (!safe(artifact.path)) throw new Error("KIT_PATH_INVALID");
    const files = await tree(path.join(dir, artifact.path));
    if (JSON.stringify(files) !== JSON.stringify(artifact.files))
      throw new Error("KIT_FILE_LIST");
    const h = createHash("sha256");
    for (const file of files)
      h.update(file)
        .update("\0")
        .update(await readFile(path.join(dir, artifact.path, file)))
        .update("\0");
    if (h.digest("hex") !== artifact.sha256) throw new Error("KIT_TREE_HASH");
  }
  const expected = [
    "wanx-app-kit.json",
    sdk.packageFile,
    ...manifest.artifacts.flatMap((a) => a.files.map((f) => a.path + "/" + f)),
  ].sort();
  if (JSON.stringify((await tree(dir)).sort()) !== JSON.stringify(expected))
    throw new Error("KIT_EXTRA_FILES");
  // Verify the delivered npm archive against its SDK tree, without a second lock.
  // Accept regular-file npm tar entries only; never extract paths to disk.
  const tar = gunzipSync(archive, { maxOutputLength: 128 * 1024 * 1024 });
  const seen = new Set();
  let offset = 0;
  for (; offset + 512 <= tar.length; ) {
    const header = tar.subarray(offset, offset + 512);
    if (header.every(byte => byte === 0)) break;
    const field = (start, end) => header.subarray(start, end).toString("utf8").replace(/\0.*$/s, "");
    const name = field(0, 100);
    const sizeText = field(124, 136).trim();
    const checksumText = field(148, 156).trim();
    const checksum = header.reduce((sum, byte, index) => sum + (index >= 148 && index < 156 ? 32 : byte), 0);
    const file = name.slice(8);
    if (!/^[0-7]+$/.test(sizeText) || !/^[0-7]+$/.test(checksumText) ||
        parseInt(checksumText, 8) !== checksum || !name.startsWith("package/") ||
        !safe(file) || !sdk.files.includes(file) || seen.has(file) ||
        ![0, 48].includes(header[156]) || field(345, 500)) throw new Error("KIT_PACKAGE_INVALID");
    const size = parseInt(sizeText, 8);
    const end = offset + 512 + size;
    if (end > tar.length || !tar.subarray(offset + 512, end).equals(await readFile(path.join(dir, sdk.path, file))))
      throw new Error("KIT_PACKAGE_CONTENT_MISMATCH");
    seen.add(file);
    offset += 512 + Math.ceil(size / 512) * 512;
  }
  if (seen.size !== sdk.files.length || tar.length - offset < 1024 ||
      !tar.subarray(offset).every(byte => byte === 0)) throw new Error("KIT_PACKAGE_INVALID");
  return { manifest, dir, version, packageFile: sdk.packageFile,
    revision: manifest.source?.revision ?? null,
    manifestSha256: hash(bytes), packageSha256: hash(archive),
    packageIntegrity: "sha512-" + createHash("sha512").update(archive).digest("base64") };

}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  try {
    await checkKit(process.argv[2] === "--root" ? process.argv[3] : undefined);
    console.log("App Kit integrity: PASS");
  } catch {
    console.error("APP_KIT_INTEGRITY_FAILED");
    process.exitCode = 1;
  }
}
