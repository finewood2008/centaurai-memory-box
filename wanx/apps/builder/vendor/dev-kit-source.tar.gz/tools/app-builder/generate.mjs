import { lstat, mkdir, open, rmdir, stat, unlink } from "node:fs/promises";
import path from "node:path";
import { parseArgs } from "node:util";
import { validateProjects } from "./project.mjs";
import {
  identityPolicy,
  json,
  planScaffold,
  readJson,
  reservedIdentity,
} from "./scaffold.mjs";

async function outputAvailable(out) {
  try {
    await lstat(out);
    return false;
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    return true;
  }
}

async function writeScaffold(out, files, manifest) {
  await mkdir(out);
  const directories = new Set([out]);
  const written = [];
  try {
    for (const [name, contents] of Object.entries({
      ...files,
      "generation-manifest.json": json(manifest),
    })) {
      if (
        path.isAbsolute(name) ||
        name
          .split("/")
          .some((part) => !part || part === ".." || part === ".") ||
        name.includes("\\")
      )
        throw new Error("UNSAFE_OUTPUT_PATH");
      const file = path.join(out, name);
      const directory = path.dirname(file);
      let current = out;
      for (const part of path
        .relative(out, directory)
        .split(path.sep)
        .filter(Boolean)) {
        current = path.join(current, part);
        if (!directories.has(current)) {
          await mkdir(current);
          directories.add(current);
        }
      }
      const handle = await open(file, "wx");
      written.push(file);
      try {
        await handle.writeFile(contents);
      } finally {
        await handle.close();
      }
    }
  } catch (error) {
    await Promise.allSettled(written.map((file) => unlink(file)));
    for (const directory of [...directories].reverse()) {
      // A concurrent writer may have left a file here. Only remove empty directories.
      await rmdir(directory).catch(() => {});
    }
    throw error;
  }
}

async function generate() {
  let options;
  try {
    ({ values: options } = parseArgs({
      options: {
        spec: { type: "string" },
        out: { type: "string" },
        inventory: { type: "string" },
        "dry-run": { type: "boolean" },
      },
    }));
  } catch {
    return [{ code: "ARGUMENTS_INVALID" }];
  }
  if (!options.spec || !options.out || options.inventory === "")
    return [{ code: "ARGUMENTS_INVALID" }];

  let spec;
  let inventory;
  try {
    spec = await readJson(options.spec);
    inventory = options.inventory ? await readJson(options.inventory) : [];
  } catch {
    return [{ code: "CONFIG_READ_OR_JSON_INVALID" }];
  }

  const validation = validateProjects(
    Array.isArray(inventory) ? [spec, ...inventory] : null,
  );
  if (!validation.valid) return validation.errors;
  if (reservedIdentity(spec, identityPolicy.identities))
    return [{ code: "RESERVED_PROJECT_IDENTITY" }];

  const out = path.resolve(options.out);
  try {
    if (!(await outputAvailable(out))) return [{ code: "OUTPUT_EXISTS" }];
    if (!(await stat(path.dirname(out))).isDirectory())
      return [{ code: "OUTPUT_PARENT_INVALID" }];
  } catch {
    return [{ code: "OUTPUT_PARENT_INVALID" }];
  }

  const { files, manifest } = await planScaffold(spec);
  if (!options["dry-run"]) {
    try {
      await writeScaffold(out, files, manifest);
    } catch (error) {
      return [
        {
          code:
            error.code === "EEXIST" ? "OUTPUT_EXISTS" : "OUTPUT_WRITE_FAILED",
        },
      ];
    }
  }
  console.log(
    json({ dryRun: Boolean(options["dry-run"]), manifest }).trimEnd(),
  );
  return [];
}

const errors = await generate().catch(() => [{ code: "SCAFFOLD_PLAN_FAILED" }]);
if (errors.length) {
  console.error(json({ errors }).trimEnd());
  process.exitCode = 1;
}
