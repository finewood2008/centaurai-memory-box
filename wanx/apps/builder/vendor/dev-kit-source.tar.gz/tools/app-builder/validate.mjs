import { lstat, readFile } from "node:fs/promises";
import path from "node:path";
import { isDeepStrictEqual, parseArgs } from "node:util";
import { validateProject } from "./project.mjs";
import {
  digest,
  generationSchemaVersion,
  identityPolicy,
  json,
  planScaffold,
  reservedIdentity,
  templates,
} from "./scaffold.mjs";

const { validDefinition } = await import(new URL("octop-expert/validate.mjs", templates));
const { applicationManifestError } = await import(
  new URL("standard-host-app/tools/application-manifest.mjs", templates)
);

async function projectFile(project, relative) {
  const parts = relative.split("/");
  let location = project;
  for (const directory of parts.slice(0, -1)) {
    location = path.join(location, directory);
    if (!(await lstat(location)).isDirectory())
      throw new Error("PROJECT_DIRECTORY_INVALID");
  }
  const file = path.join(location, parts.at(-1));
  if (!(await lstat(file)).isFile()) throw new Error("PROJECT_FILE_INVALID");
  return readFile(file);
}

async function validate() {
  let project;
  try {
    const { values } = parseArgs({ options: { project: { type: "string" } } });
    if (!values.project) return { errors: [{ code: "ARGUMENTS_INVALID" }] };
    project = path.resolve(values.project);
  } catch {
    return { errors: [{ code: "ARGUMENTS_INVALID" }] };
  }

  let spec;
  let stored;
  try {
    if (!(await lstat(project)).isDirectory())
      return { errors: [{ code: "PROJECT_DIRECTORY_INVALID" }] };
    spec = JSON.parse(await projectFile(project, "project-spec.json"));
    stored = JSON.parse(await projectFile(project, "generation-manifest.json"));
  } catch {
    return { errors: [{ code: "PROJECT_METADATA_INVALID" }] };
  }

  if (stored.schemaVersion !== generationSchemaVersion)
    return {
      errors: [
        {
          code: "GENERATOR_VERSION_UNSUPPORTED",
          expected: generationSchemaVersion,
          actual: Number.isSafeInteger(stored.schemaVersion)
            ? stored.schemaVersion
            : null,
        },
      ],
    };
  const validation = validateProject(spec);
  if (!validation.valid) return { errors: validation.errors };
  if (reservedIdentity(spec, identityPolicy.identities))
    return { errors: [{ code: "RESERVED_PROJECT_IDENTITY" }] };

  const { manifest } = await planScaffold(spec);
  if (!isDeepStrictEqual(stored, manifest))
    return { errors: [{ code: "MANIFEST_MISMATCH" }] };

  const application = JSON.parse(
    await projectFile(project, "application.manifest.json"),
  );
  if (application.applicationId !== spec.applicationId)
    return { errors: [{ code: "APPLICATION_IDENTITY_MISMATCH" }] };
  const manifestError = applicationManifestError(application);
  if (manifestError) return { errors: [{ code: manifestError }] };

  const errors = [];
  if (spec.expert.enabled) {
    try {
      const definition = JSON.parse(
        await projectFile(project, "expert/definition.json"),
      );
      if (
        !validDefinition(definition) ||
        definition.definitionRef !== spec.expert.definitionRef
      )
        errors.push({ code: "EXPERT_DEFINITION_INVALID" });
    } catch {
      errors.push({ code: "EXPERT_DEFINITION_INVALID" });
    }
  }
  const modifiedFiles = [];
  for (const [file, sha256] of Object.entries(manifest.files)) {
    try {
      if (digest(await projectFile(project, file)) !== sha256) {
        if (file.startsWith("vendor/"))
          errors.push({ code: "PROJECT_ARTIFACT_MODIFIED", file });
        else modifiedFiles.push(file);
      }
    } catch {
      if (file.startsWith("app/") && !["app/host.html", "app/host.mjs"].includes(file)) modifiedFiles.push(file);
      else errors.push({ code: "PROJECT_FILE_INVALID", file });
    }
  }
  return { errors, modifiedFiles };
}

const result = await validate().catch(() => ({
  errors: [{ code: "SCAFFOLD_VALIDATION_FAILED" }],
}));
console.log(
  json({
    valid: result.errors.length === 0,
    target: "wanx-host-shared",
    ...result,
  }).trimEnd(),
);
if (result.errors.length) process.exitCode = 1;
