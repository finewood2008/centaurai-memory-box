import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {parseArgs} from 'node:util';

function inspect() {
  let project;
  try {
    const {values} = parseArgs({options: {project: {type: 'string'}}});
    project = values.project;
    if (!project) return {valid: false, errors: [{code: 'ARGUMENTS_INVALID'}]};
  } catch {
    return {valid: false, errors: [{code: 'ARGUMENTS_INVALID'}]};
  }

  const validator = fileURLToPath(new URL('./validate.mjs', import.meta.url));
  const result = spawnSync(process.execPath, [validator, '--project', project], {
    encoding: 'utf8', timeout: 30000, maxBuffer: 1024 * 1024,
  });
  try {
    const validation = JSON.parse(result.stdout);
    return {...validation, valid: result.status === 0 && validation.valid === true};
  } catch {
    return {valid: false, errors: [{code: 'PROJECT_VALIDATION_FAILED'}]};
  }
}

const validation = inspect();
const report = {
  schemaVersion: 1,
  readiness: validation.valid ? 'scaffold-valid' : 'invalid',
  checks: {
    scaffold: {
      status: validation.valid ? 'passed' : 'failed',
      errors: validation.errors.map(({code}) => ({code})),
      modifiedFiles: validation.modifiedFiles || [],
    },
    application: {status: 'not-run'},
    build: {status: 'not-run'},
    platform: {status: 'not-run'},
  },
};
console.log(JSON.stringify(report, null, 2));
if (!validation.valid) process.exitCode = 1;
