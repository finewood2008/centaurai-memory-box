import {readFile} from 'node:fs/promises';
import {validateProject} from './project.mjs';
const args=process.argv.slice(2);
if (args.length !== 1) {
  console.error('Usage: npm run check:config -- <project-spec.json>'); process.exitCode=1;
} else {
  try {
    const result=validateProject(JSON.parse(await readFile(args[0], 'utf8')));
    console.log(JSON.stringify(result, null, 2));
    if (!result.valid) process.exitCode=1;
  } catch {
    console.error('CONFIG_READ_OR_JSON_INVALID'); process.exitCode=1;
  }
}
