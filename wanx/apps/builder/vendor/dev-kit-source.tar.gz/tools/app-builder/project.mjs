import {readFileSync} from 'node:fs';
import Ajv from 'ajv';
const schema = JSON.parse(readFileSync(new URL('../../contracts/app-builder/project.schema.json', import.meta.url), 'utf8'));
const validate = new Ajv({allErrors: true, strict: true}).compile(schema);

/** Validate development configuration only; references do not prove readiness. */
export function validateProject(value) {
  validate(value);
  const errors = (validate.errors || []).map(e => ({
    code: value?.backend?.mode === 'custom' && value.backend.deployment === 'box' && e.keyword === 'required' && e.params.missingProperty === 'deploymentRef' ? 'BOX_DEPLOYMENT_REQUIRED' : 'PROJECT_SCHEMA_INVALID',
    path: e.instancePath,
    keyword: e.keyword,
  }));
  const seen = new Set();
  if (Array.isArray(value?.capabilities)) for (const item of value.capabilities) {
    if (item && seen.has(item.id)) errors.push({code: 'DUPLICATE_CAPABILITY', path: '/capabilities'});
    seen.add(item?.id);
  }
  return {valid: errors.length === 0, errors};
}

export function validateProjects(values) {
  if (!Array.isArray(values)) return {valid:false, errors:[{code:'PROJECT_LIST_REQUIRED'}]};
  const errors = [];
  const ids = new Set(), slugs = new Set();
  values.forEach((value, index) => {
    errors.push(...validateProject(value).errors.map(e => ({...e, index})));
    if (ids.has(value?.applicationId) || slugs.has(value?.slug)) errors.push({code:'DUPLICATE_PROJECT_IDENTITY', index});
    ids.add(value?.applicationId); slugs.add(value?.slug);
  });
  return {valid: errors.length === 0, errors};
}
