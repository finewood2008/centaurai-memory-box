import { checkKit } from "../app-kit/check.mjs";
import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";

const root = new URL("../../", import.meta.url);

export const json = (value) => JSON.stringify(value, null, 2) + "\n";
export const readJson = async (file) =>
  JSON.parse(await readFile(file, "utf8"));
export const digest = (contents) =>
  createHash("sha256").update(contents).digest("hex");

async function readTemplate(file) {
  return (await readFile(file, "utf8")).replace(/\r\n/g, "\n");
}

export function reservedIdentity(spec, identities) {
  return identities.some(
    ({ slug, applicationId }) =>
      slug === spec.slug || applicationId === spec.applicationId,
  );
}

export const identityPolicy = await readJson(
  new URL("contracts/app-builder/reserved-identities.json", root),
);
const kit = await readJson(new URL("package.json", root));
export const templates = new URL(kit.templateDirectory ?? "templates/", root);
const appTemplate = new URL("standard-host-app/", templates);
const expertTemplate = new URL("octop-expert/", templates);
export const generationSchemaVersion = 6;

function canonical(value) {
  if (Array.isArray(value)) return value.map(canonical);
  if (value && typeof value === "object") {
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .map((key) => [key, canonical(value[key])]),
    );
  }
  return value;
}

export async function planScaffold(spec) {
  const verified = await checkKit();
  const dependency = "file:vendor/" + verified.packageFile;
  const dependencies = (await readJson(new URL("dependency-lock.json", appTemplate))).packages;
  // npm packaging can produce different archive bytes for the same verified SDK tree.
  dependencies["node_modules/@centaurai/wanx-host-sdk"] = {
    ...dependencies["node_modules/@centaurai/wanx-host-sdk"],
    resolved: dependency,
    integrity: verified.packageIntegrity,
  };
  const packageRoot = {
    name: "wanx-" + spec.slug,
    version: "0.0.0",
    engines: kit.engines,
    dependencies: { "@centaurai/wanx-host-sdk": dependency },
    devDependencies: { semver: kit.devDependencies.semver },
  };
  const pkg = {
    ...packageRoot,
    private: true,
    type: "module",
    scripts: {
      check: "node tools/local.mjs check",
      build: "node tools/local.mjs build",
      package: "node tools/package.mjs",
    },
  };
  const files = {
    "project-spec.json": json(canonical(spec)),
    "package.json": json(pkg),
    "package-lock.json": json({
      name: pkg.name,
      version: pkg.version,
      lockfileVersion: 3,
      requires: true,
      packages: {
        "": packageRoot,
        ...dependencies,
      },
    }),
    ".gitignore": "node_modules/\ndist/\nlocal-packages/\n.env\n.env.*\n",
  };

  for (const name of [
    "README.md",
    "tools/local.mjs",
    "tools/build-files.mjs",
    "tools/application-manifest.mjs",
    "tools/package.mjs",
    "app/host.html",
    "app/host.mjs",
    "app/styles.css",
    "app/ui.mjs",
    "app/pages/workspace.mjs",
    "app/pages/tasks.mjs",
    "app/pages/settings.mjs",
    "shell/main.cjs",
    "shell/host.cjs",
    "shell/preload.cjs",
  ]) {
    files[name] = await readTemplate(new URL(name, appTemplate));
  }
  files["vendor/" + verified.packageFile] = await readFile(
    new URL(
      "vendor/wanx-app-kit/" +
        verified.version +
        "/" +
        verified.packageFile,
      root,
    ),
  );
  files["application.manifest.json"] = json({
    applicationId: spec.applicationId,
    name: spec.slug,
    version: "0.0.0",
    protocolVersion: 3,
    runtime: "electron",
    launchMode: "shared",
    entrypoint: "shell/main.cjs",
    capabilities: ["identity.read", "http.request"],
    compatibility: {
      backendProductId: "wanx",
      clientRange: ">=0.1.0 <2.0.0",
      hostProtocolRange: ">=1.0.0 <2.0.0",
      backendContracts: spec.backend.mode === "existing" && spec.backend.connectionRef === "wanx.expert-app.v1"
        ? [{ id: "wanx.expert-app.v1", range: ">=1.0.0 <2.0.0", features: ["context", "expert", "data"] }]
        : [],
      resourceDependencies: [],
      localDataSchema: { readRange: "=1.0.0", writeVersion: "1.0.0" },
    },
  });
  if (spec.backend.mode !== "none") {
    files["integration/README.md"] = await readTemplate(
      new URL("service-integration/README.md", templates),
    );
    files["integration/selection.json"] = json(canonical(spec.backend));
  }
  if (spec.expert.enabled) {
    const definition = await readJson(
      new URL("definition.json", expertTemplate),
    );
    files["expert/definition.json"] = json({
      ...definition,
      definitionRef: spec.expert.definitionRef,
    });
    for (const name of [
      "README.md",
      "instructions.md",
      "skills/service-use/SKILL.md",
      "definition.schema.json",
      "validate.mjs",
    ])
      files["expert/" + name] = await readTemplate(
        new URL(name, expertTemplate),
      );
  }

  const hashes = Object.fromEntries(
    Object.entries(files).map(([name, contents]) => [name, digest(contents)]),
  );
  return {
    files,
    manifest: {
      schemaVersion: generationSchemaVersion,
      target: "wanx-host-shared",
      kitVersion: kit.version,
      slug: spec.slug,
      applicationId: spec.applicationId,
      identityPolicyRef: identityPolicy.sourceRef,
      uiTemplate: { id: "workspace-reference", version: 1, layoutEditable: true },
      appKit: {
        version: verified.version,
        status: "vendored-verified",
        packageSha256: verified.packageSha256,
      },
      files: hashes,
    },
  };
}
