import {readFile} from 'node:fs/promises';
import {parseArgs} from 'node:util';
import {pathToFileURL} from 'node:url';
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const id = value => typeof value === 'string' && value.length <= 64 && /^[a-z][a-z0-9]*(?:[.-][a-z0-9]+)+$/.test(value);
const route = value => typeof value === 'string' && /^\/api\/(?:[a-z0-9]+(?:[.-][a-z0-9]+)*\/)*[a-z0-9]+(?:[.-][a-z0-9]+)*$/.test(value) && value.length <= 128;
function upstream(value) {
 if(typeof value !== 'string') return false;
 try {const url=new URL(value); return /^http:\/\/127\.0\.0\.1:[0-9]+$/.test(value) && url.port !== '' && Number(url.port)>1023 && !url.username && !url.password;} catch{return false;}
}
export function preflight(plan,snapshot) {
 const result=(code)=>({ready:false,code,registered:false,deployed:false});
 if(!object(plan) || Object.keys(plan).sort().join(',') !== 'applicationId,routePrefix,schemaVersion,serviceId,upstream' || plan.schemaVersion!==1 || !id(plan.serviceId) || !id(plan.applicationId) || !upstream(plan.upstream) || !route(plan.routePrefix)) return result('SERVICE_PLAN_INVALID');
 if(!object(snapshot) || snapshot.schemaVersion!==1 || snapshot.registrationMode!=='fixed' || !Array.isArray(snapshot.services) || !snapshot.services.length || snapshot.services.some(item=>!object(item) || !id(item.serviceId) || !upstream(item.upstream) || !route(item.routePrefix))) return result('BRIDGE_CAPABILITY_UNVERIFIED');
 if(snapshot.services.some(item=>item.serviceId===plan.serviceId)) return result('BRIDGE_SERVICE_ID_OCCUPIED');
 return result('BRIDGE_GENERIC_REGISTRATION_UNAVAILABLE');
}
if(process.argv[1] && import.meta.url===pathToFileURL(process.argv[1]).href) {
 let result;
 try {
  const {values}=parseArgs({options:{plan:{type:'string'},snapshot:{type:'string'}}});
  if(!values.plan || !values.snapshot) throw new Error();
  result=preflight(JSON.parse(await readFile(values.plan,'utf8')),JSON.parse(await readFile(values.snapshot,'utf8')));
 } catch {result={ready:false,code:'PREFLIGHT_INPUT_INVALID',registered:false,deployed:false};}
 console.log(JSON.stringify(result,null,2)); process.exitCode=result.ready?0:2;
}
