import {checkKit} from './app-kit/check.mjs';
import {readFile,readdir} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {spawnSync} from 'node:child_process';
import {checkDocuments,checkHandover} from './repository.mjs';
import {validateProjects} from './app-builder/project.mjs';
const root=fileURLToPath(new URL('../',import.meta.url));
await checkKit();
const results=await Promise.all([checkDocuments(root),checkHandover(root)]);
const dir=path.join(root,'examples/project-specs');
const samples=await Promise.all((await readdir(dir)).filter(f=>f.endsWith('.json')).map(async f=>JSON.parse(await readFile(path.join(dir,f),'utf8'))));
const errors=[...results.flat(),...validateProjects(samples).errors];
if (errors.length) {console.error(JSON.stringify(errors,null,2));process.exitCode=1;}
const deployment=spawnSync(process.execPath,['tools/deployment/validate.mjs','samples'],{cwd:root,stdio:'inherit'});
if (deployment.status!==0 || deployment.error) process.exitCode=1;
const tests=spawnSync(process.execPath,['--test'],{cwd:root,stdio:'inherit'});
if (tests.status!==0 || tests.error) process.exitCode=1;
if (!process.exitCode) console.log('Repository checks: PASS');
