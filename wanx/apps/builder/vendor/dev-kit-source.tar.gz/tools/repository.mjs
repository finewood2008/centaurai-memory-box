import {readdir, readFile, access} from 'node:fs/promises';
import path from 'node:path';
export async function filesUnder(root) {
  const files=[];
  for (const entry of await readdir(root,{withFileTypes:true})) {
    if (['.git','node_modules','.superpowers'].includes(entry.name)) continue;
    const file=path.join(root,entry.name);
    if (entry.isDirectory()) files.push(...await filesUnder(file));
    else if (entry.isFile()) files.push(file);
  }
  return files;
}
function prose(text) {
  let fence=null; const lines=[];
  for (const line of text.split('\n')) {
    const match=line.match(/^\s*(`{3,}|~{3,})(.*)$/);
    if (match) {
      if (!fence) fence={char:match[1][0], length:match[1].length};
      else if (match[1][0]===fence.char && match[1].length>=fence.length && !match[2].trim()) fence=null;
      continue;
    }
    if (!fence) lines.push(line);
  }
  return {text:lines.join('\n'), unclosed:Boolean(fence)};
}
export async function checkDocuments(root) {
  const errors=[];
  for (const file of (await filesUnder(root)).filter(f=>f.endsWith('.md'))) {
    // Upstream generated kit docs are immutable and checked by check:kit, not rewritten for local links.
    if(path.relative(root,file).split(path.sep).slice(0,2).join('/') === 'vendor/wanx-app-kit') continue;
    const content=prose(await readFile(file,'utf8'));
    const name=path.relative(root,file);
    if (content.unclosed) errors.push({code:'UNCLOSED_FENCE',file:name});
    for (const match of content.text.matchAll(/\]\((?:<([^>]+)>|([^\s)]+))\)/g)) {
      const link=match[1] || match[2];
      if (/^(https?:|mailto:|#)/.test(link)) continue;
      if (path.isAbsolute(link) || /^[a-z]+:/i.test(link)) {errors.push({code:'NON_PORTABLE_LINK',file:name});continue;}
      try {
        const resolved=path.resolve(path.dirname(file),decodeURIComponent(link.split('#')[0]));
        if (path.relative(root,resolved).startsWith('..')) errors.push({code:'NON_PORTABLE_LINK',file:name});
        else await access(resolved);
      } catch {errors.push({code:'BROKEN_LINK',file:name});}
    }
  }
  return errors;
}
export async function checkHandover(root) {
  const errors=[];
  let board;
  try {board=await readFile(path.join(root,'HANDOVER.md'),'utf8');} catch {return [{code:'HANDOVER_MISSING'}];}
  const notes=[...board.matchAll(/\]\((maintenance\/handovers\/[a-zA-Z0-9_-]+\.md)\)/g)].map(m=>m[1]);
  if (!notes.length) errors.push({code:'HANDOVER_NOTE_REQUIRED'});
  for (const note of notes) {
    try {
      const text=await readFile(path.join(root,note),'utf8');
      const lines=text.split('\n');
      for (const heading of ['更新内容','验证','下一步']) {
        const start=lines.findIndex(line=>line.startsWith(`## ${heading}`));
        const body=[];
        if (start>=0) for (const line of lines.slice(start+1)) {
          if (/^#{1,2}\s/.test(line)) break;
          body.push(line);
        }
        if (!body.some(line=>line.trim() && !/^\s*#/.test(line))) errors.push({code:'HANDOVER_SECTION_REQUIRED',file:note,heading});
      }
    } catch {errors.push({code:'HANDOVER_NOTE_MISSING',file:note});}
  }
  return errors;
}
