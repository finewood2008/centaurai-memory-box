import { execFileSync } from 'node:child_process';
import { copyFile, cp, lstat, mkdir, mkdtemp, readFile, readdir, realpath, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';
import { checkDocuments } from './repository.mjs';

const root = fileURLToPath(new URL('../', import.meta.url));
const skillSource = 'skills/wanx-app-development/SKILL.md';
const guideSource = 'docs/developer-guide';
const resourceDirectories = {
  [guideSource]: 'references',
  templates: 'assets/templates',
  // Deployment v1 is a platform-integration draft, not an application-development input.
  'contracts/app-builder': 'contracts/app-builder',
  'examples/project-specs': 'examples/project-specs',
  'vendor/wanx-app-kit/0.3.0': 'vendor/wanx-app-kit/0.3.0',
  'tools/app-builder': 'scripts/app-builder',
};
const resourceFiles = {
  [skillSource]: 'SKILL.md',
  'tools/app-kit/check.mjs': 'scripts/app-kit/check.mjs',
  'tools/bridge-service/preflight.mjs': 'scripts/bridge-service/preflight.mjs',
  'package-lock.json': 'package-lock.json',
};
const commands = [
  'check:config', 'generate', 'check:project', 'check:kit', 'report', 'check:bridge-service',
];

function packagedPath(source) {
  if (Object.hasOwn(resourceFiles, source)) return resourceFiles[source];
  for (const [directory, destination] of Object.entries(resourceDirectories)) {
    if (source === directory || source.startsWith(directory + '/')) {
      return destination + source.slice(directory.length);
    }
  }
  throw new Error('SKILL_REFERENCE_NOT_PACKAGED: ' + source);
}

function trackedResources() {
  const inputs = [...Object.keys(resourceDirectories), ...Object.keys(resourceFiles)];
  return execFileSync('git', ['ls-files', '--cached', '--deduplicate', '-z', '--', ...inputs], {
    cwd: root,
    encoding: 'utf8',
  }).split('\0').filter(Boolean);
}

async function copyResource(source, destination) {
  const input = path.join(root, source);
  const info = await lstat(input).catch(error => {
    if (error.code === 'ENOENT') return null;
    throw error;
  });
  if (!info) return; // A tracked file may have been removed in the current checkout.
  if (!info.isFile() || await realpath(input) !== input) {
    throw new Error('SKILL_RESOURCE_NOT_REGULAR: ' + source);
  }
  if (source.startsWith(guideSource + '/')) {
    await copyGuide(source, destination);
    return;
  }
  const target = path.join(destination, packagedPath(source));
  await mkdir(path.dirname(target), { recursive: true });
  await copyFile(input, target);
}

async function copyGuide(source, destination) {
  const target = packagedPath(source);
  const content = await readFile(path.join(root, source), 'utf8');
  const packaged = content.replace(/\]\((\.\.\/[^\s)#]+)(#[^\s)]+)?\)/g, (_, link, anchor = '') => {
    const sourceTarget = path.posix.normalize(path.posix.join(path.posix.dirname(source), link));
    return '](' + path.posix.relative(path.posix.dirname(target), packagedPath(sourceTarget)) + anchor + ')';
  });
  await writeFile(path.join(destination, target), packaged);
}

async function buildSkill(destination) {
  const staging = await mkdtemp(path.join(tmpdir(), 'wanx-skill-package-'));
  try {
    await mkdir(path.join(staging, 'references'));
    for (const source of trackedResources()) await copyResource(source, staging);

    const manifest = JSON.parse(await readFile(path.join(root, 'package.json'), 'utf8'));
    manifest.scripts = Object.fromEntries(commands.map(name => [
      name, manifest.scripts[name].replace('node tools/', 'node scripts/'),
    ]));
    manifest.templateDirectory = 'assets/templates/';
    await writeFile(path.join(staging, 'package.json'), JSON.stringify(manifest, null, 2) + '\n');
    const errors = await checkDocuments(staging);
    if (errors.length) throw new Error('SKILL_DOCUMENTS_INVALID: ' + JSON.stringify(errors));

    try {
      await mkdir(destination);
    } catch (error) {
      if (error.code === 'EEXIST') throw new Error('SKILL_OUTPUT_EXISTS');
      throw error;
    }
    try {
      for (const name of await readdir(staging)) {
        await cp(path.join(staging, name), path.join(destination, name), {
          recursive: true,
          force: false,
          errorOnExist: true,
        });
      }
    } catch (error) {
      throw new Error('SKILL_OUTPUT_INCOMPLETE: ' + error.message);
    }
  } finally {
    await rm(staging, { recursive: true, force: true });
  }
}

try {
  const { values } = parseArgs({ options: { out: { type: 'string' } } });
  if (!values.out || path.basename(path.resolve(values.out)) !== 'wanx-app-development') {
    throw new Error('用法：npm run pack:skill -- --out /existing/parent/wanx-app-development');
  }
  await buildSkill(path.resolve(values.out));
  console.log('Skill package: ' + path.resolve(values.out));
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
