import {fileURLToPath} from 'node:url';
import {checkHandover} from './repository.mjs';
const errors=await checkHandover(fileURLToPath(new URL('../',import.meta.url)));
if (errors.length) {console.error(JSON.stringify(errors,null,2));process.exitCode=1;}
else console.log('Handover: PASS');
